
QNX Neutrino for:     BSP_ti-j6eco-dra72x-evm_br-660_be-660
SVN Revision Number:  797070
Build Number:         54

For documentation related to this BSP please refer to:

  http://community.qnx.com/sf/wiki/do/viewPage/projects.bsp/wiki/BSPAndDrivers

