/*
 * $QNXtpLicenseC:  
 * Copyright 2014, QNX Software Systems. All Rights Reserved.
 *
 * This source code may contain confidential information of QNX Software 
 * Systems (QSS) and its licensors.  Any use, reproduction, modification, 
 * disclosure, distribution or transfer of this software, or any software 
 * that includes or is based upon any of this code, is prohibited unless 
 * expressly authorized by QSS by written agreement.  For more information 
 * (including whether this source code file has been published) please
 * email licensing@qnx.com. $
*/


/*
 * The xelem_t is a simple container which is used to group all transfer parameters
 * ( urb, buffer addr, length, flags, xfer type etc... ) as well as transfer state variables.
 *
 * This grouping is useful for associating the software ( xelem_t ) parameters with a hardware
 * transfer descriptor ( trb ).  When a transfer is complete and a transfer complete event is
 * generated, then a simple xelem lookup is performed to get all the key transfer context use
 * to complete the transfer up the stack.   
 */ 


#include "dwcotg.h"


////////////////////////////////////////////////////////////////////////////////
//                             PUBLIC                                         //
////////////////////////////////////////////////////////////////////////////////

int xelem_pool_create( dctrl_t * dc, int size ) {
	fbma_attr_t     *attr;

	// create attribute struct
	attr = fbma_attr_create();
	if ( attr == NULL ) {
		dwcotg_slogf( dc, _SLOG_ERROR, "%s: could not create pool attributes",__func__);
		goto fail;
	}

	// set desired attributes for the pool
	fbma_attr_blksz_set( attr, sizeof( xelem_t ) );
	fbma_attr_nblk_set( attr, size );
	fbma_attr_maxpool_set( attr, 4 );  // allocate up to 4 pools on demand if needed	

	// create the allocator
	dc->xelem_pool = fbma_create( attr );
	if ( dc->xelem_pool == NULL ) {
		dwcotg_slogf( dc, _SLOG_ERROR, "%s: could not create pool ",__func__);
		goto fail2;
	}

	// we don't need attr struct once the allocator is created
	fbma_attr_destroy( attr );

	return EOK;

fail2:
	fbma_attr_destroy( attr );
fail:
	return ENOMEM;
}


void xelem_pool_destroy( dctrl_t *dc ) {
	fbma_destroy( dc->xelem_pool );
}

xelem_t * xelem_create( dctrl_t *dc, iousb_transfer_t *urb, iousb_endpoint_t *iousb_ep,
            uint32_t buffer_paddr64,  _uint32 length, _uint32 flags )
{
    xelem_t     *xelem;

	xelem = fbma_alloc( dc->xelem_pool, NULL );
	if ( xelem == NULL ) {
		dwcotg_slogf( dc, _SLOG_ERROR, "%s: Couldn't allocate XFER Element",__func__);
		goto error;
	}
	xelem->urb            =  urb;
	xelem->iousb_ep       =  iousb_ep;
	xelem->buffer_paddr64 =  buffer_paddr64;
	xelem->length         =  length;
	xelem->flags          =  flags;
	xelem->xflags         =  0;
 
	// initialize state vars 
	xelem->bytes_xfered = 0;
	xelem->frag_cnt = 0;
	xelem->n_frag = 1;
	
	return xelem;
error:
	return NULL;
}


void xelem_destroy( dctrl_t *dc, xelem_t * xelem  ) {
	fbma_free( dc->xelem_pool, xelem );
}

#if defined(__QNXNTO__) && defined(__USESRCVERSION)
#include <sys/srcversion.h>
__SRCVERSION("$URL: http://svn.ott.qnx.com/product/branches/6.6.0/trunk/hardware/devu/dc/dwcotg3/xelem.c $ $Rev: 776864 $")
#endif


