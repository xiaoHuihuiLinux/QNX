/*
 * $QNXLicenseC:
 * Copyright 2014, QNX Software Systems.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"). You
 * may not reproduce, modify or distribute this software except in
 * compliance with the License. You may obtain a copy of the License
 * at: http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OF ANY KIND, either express or implied.
 *
 * This file may contain contributions from others, either as
 * contributors under the License or as licensors under other terms.
 * Please review this entire file for other proprietary rights or license
 * notices, as well as the QNX Development Suite License Guide at
 * http://licensing.qnx.com/license-guide/ for other information.
 * $
 */

#include "board.h"

/* Pin Mux Registers and the Corresponding Values */
static unsigned early_pin_data_dp[] = {
	UART1_RXD, (IEN | SSC | M0),
	UART1_TXD, (IEN | SSC | M0),
	I2C1_SDA, (IEN | PDIS | M0),
	I2C1_SCL, (IEN | PDIS | M0),
};

/* Pin Mux Registers and the Corresponding Values */
static unsigned pin_data_dp[] = {
	MMC1_CLK, (IEN | PTU | PDIS | M0),
	MMC1_CMD, (IEN | PTU | PDIS | M0),
	MMC1_DAT0, (IEN | PTU | PDIS | M0),
	MMC1_DAT1, (IEN | PTU | PDIS | M0),
	MMC1_DAT2, (IEN | PTU | PDIS | M0),
	MMC1_DAT3, (IEN | PTU | PDIS | M0),
	MMC1_SDCD, (FSC | IEN | PTU | PDIS | M0),
	MMC1_SDWP, (FSC | IEN | PTD | PEN | M14),

	UART1_RXD, (FSC | IEN | PTU | PDIS | M0),
	UART1_TXD, (FSC | IEN | PTU | PDIS | M0),

	I2C1_SDA, (IEN | PTU | PDIS | M0),
	I2C1_SCL, (IEN | PTU | PDIS | M0),

	GPMC_A13, (IEN | PDIS | M1),	/* qspi1_rtclk */
	GPMC_A14, (IEN | PDIS | M1),	/* qspi1_d3 */
	GPMC_A15, (IEN | PDIS | M1),	/* qspi1_d2 */
	GPMC_A16, (IEN | PDIS | M1),	/* qspi1_d0 */
	GPMC_A17, (IEN | PDIS | M1),	/* qspi1_d1 */
	GPMC_A18, (IEN | PDIS | M1),	/* qspi1_sclk */
	GPMC_CS2, (IEN | PTU | PDIS | M1), /* qspi1_cs0 */
	GPMC_A19, (IEN | PTU | M1),		/* mmc2_dat4 */
	GPMC_A20, (IEN | PTU | M1),		/* mmc2_dat5 */
	GPMC_A21, (IEN | PTU | M1),		/* mmc2_dat6 */
	GPMC_A22, (IEN | PTU | M1),		/* mmc2_dat7 */
	GPMC_A23, (IEN | PTU | M1),		/* mmc2_clk */
	GPMC_A24, (IEN | PTU | M1),		/* mmc2_dat0 */
	GPMC_A25, (IEN | PTU | M1),		/* mmc2_dat1 */
	GPMC_A26, (IEN | PTU | M1),		/* mmc2_dat2 */
	GPMC_A27, (IEN | PTU | M1),		/* mmc2_dat3 */
	GPMC_CS1, (IEN | PTU | M1),		/* mmm2_cmd */

	RGMII0_TXC, (SSC |IEN | PTD | PDIS | MANUAL_MODE | M0),
	RGMII0_TXCTL, (SSC |IEN | PTD | PDIS | MANUAL_MODE | M0),
	RGMII0_TXD3, (SSC |IEN | PTD | PDIS | MANUAL_MODE | M0),
	RGMII0_TXD2, (SSC |IEN | PTD | PDIS | MANUAL_MODE | M0),
	RGMII0_TXD1, (SSC |IEN | PTD | PDIS | MANUAL_MODE | M0),
	RGMII0_TXD0, (SSC |IEN | PTD | PDIS | MANUAL_MODE | M0),
	RGMII0_RXC, (IEN | MANUAL_MODE | M0),
	RGMII0_RXCTL, (IEN | MANUAL_MODE | M0),
	RGMII0_RXD3, (IEN | MANUAL_MODE | M0),
	RGMII0_RXD2, (IEN | MANUAL_MODE | M0),
	RGMII0_RXD1, (IEN | MANUAL_MODE | M0),
	RGMII0_RXD0, (IEN | MANUAL_MODE | M0),	
};

void dump_pinmux(void)
{
	int i, size;

		size = sizeof(pin_data_dp) / sizeof(unsigned);
		for (i = 0; i < size; i += 2)
		{
			ser_putstr("0x");
			ser_puthex(DRA72X_CONTROL_PADCONF_CORE_BASE + pin_data_dp[i]);
			ser_putstr(" : 0x");
			ser_puthex(in32(DRA72X_CONTROL_PADCONF_CORE_BASE + pin_data_dp[i]));
			ser_putstr("\n");
		}

}

/* Initialize the Early Pin Muxing */
void init_early_pinmux(void)
{
	int i, size;

	size = sizeof(early_pin_data_dp) / sizeof(unsigned);
	for (i = 0; i < size; i += 2)
		out32(DRA72X_CONTROL_PADCONF_CORE_BASE + early_pin_data_dp[i], early_pin_data_dp[i + 1]);
}


/* Initialize the Pin Muxing */
void init_pinmux(void)
{
	int i, size;

	size = sizeof(pin_data_dp) / sizeof(unsigned);
	for (i = 0; i < size; i += 2)
		out32(DRA72X_CONTROL_PADCONF_CORE_BASE + pin_data_dp[i], pin_data_dp[i + 1]);
}


#if defined(__QNXNTO__) && defined(__USESRCVERSION)
#include <sys/srcversion.h>
__SRCVERSION("$URL: http://svn.ott.qnx.com/product/branches/6.6.0/trunk/hardware/ipl/boards/dra72x/arm/evm.le.v7/init_pinmux.c $ $Rev: 779094 $")
#endif
