/*
 * $QNXLicenseC:
 * Copyright 2015, QNX Software Systems.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"). You
 * may not reproduce, modify or distribute this software except in
 * compliance with the License. You may obtain a copy of the License
 * at: http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OF ANY KIND, either express or implied.
 *
 * This file may contain contributions from others, either as
 * contributors under the License or as licensors under other terms.
 * Please review this entire file for other proprietary rights or license
 * notices, as well as the QNX Development Suite License Guide at
 * http://licensing.qnx.com/license-guide/ for other information.
 * $
 */
 
#include "board.h"

typedef struct io_delay {
	uint32_t	addr;
	uint32_t	a_dly;
	uint32_t	g_dly;
} dra7xx_io_delay_t;

/* Pin Mux Registers and the Corresponding Values */
static dra7xx_io_delay_t io_delay_dp[] = {
	{IODELAY_CONFIG_BASE + 0x6F0, 359, 0},		/* RGMMI0_RXC_IN */
	{IODELAY_CONFIG_BASE + 0x6FC, 129, 1896},	/* RGMMI0_RXCTL_IN */
	{IODELAY_CONFIG_BASE + 0x708, 80, 1391},	/* RGMMI0_RXD0_IN */
	{IODELAY_CONFIG_BASE + 0x714, 196, 1522},	/* RGMMI0_RXD1_IN */
	{IODELAY_CONFIG_BASE + 0x720, 40, 1860},	/* RGMMI0_RXD2_IN */
	{IODELAY_CONFIG_BASE + 0x72C, 0, 1956},		/* RGMMI0_RXD3_IN */
	{IODELAY_CONFIG_BASE + 0x740, 0, 220},		/* RGMMI0_TXC_OUT */
	{IODELAY_CONFIG_BASE + 0x74C, 1820, 180},	/* RGMMI0_TXCTL_OUT */
	{IODELAY_CONFIG_BASE + 0x758, 1740, 440},	/* RGMMI0_TXD0_OUT */
	{IODELAY_CONFIG_BASE + 0x764, 1740, 240},	/* RGMMI0_TXD1_OUT */
	{IODELAY_CONFIG_BASE + 0x770, 1680, 380},	/* RGMMI0_TXD2_OUT */
	{IODELAY_CONFIG_BASE + 0x77C, 1740, 440},	/* RGMMI0_TXD3_OUT */
	{0, 0, 0}
};

/*****************************************************************
 * wait_for_match - wait for the bit mask to match the given value
 *****************************************************************/
static unsigned wait_for_match(unsigned bit_mask, unsigned match, unsigned addr, unsigned delay)
{
	unsigned count = 0, value;

	do {
		++count;
		value = in32(addr) & bit_mask;
		if (value == match) {
			return (1);
		}
		if (count == delay) {
			return (0);
		}
	} while (1);
}


extern long __aeabi_uidiv (long numerator, long denominator);

long __aeabi_uidivmod (long numerator, long denominator)
{
	long c,d,e;
	c = __aeabi_uidiv(numerator , denominator);
	d = c * denominator;
	e = numerator - d;
	return e;
}

static unsigned calculate_manual_io_timing_mode(
	unsigned a_delay, unsigned g_delay, unsigned cdpe, unsigned fdpe)
{
	unsigned g_delay_coarse, g_delay_fine, a_delay_coarse, a_delay_fine;
	unsigned coarse_elements, fine_elements, total_delay, reg_val = 0;

	/* --- a:  Calculate the Coarse and Fine value for A_DELAY and G_DELAY --- */

	g_delay_coarse = __aeabi_uidiv(g_delay, 920);
	g_delay_fine = __aeabi_uidiv((g_delay % 920) * 10, 60);

	a_delay_coarse = __aeabi_uidiv(a_delay, cdpe);
	a_delay_fine = __aeabi_uidiv((a_delay % cdpe) * 10, fdpe);

	/* --- b:  Calculate the required number of Coarse and Fine elements --- */

	coarse_elements = g_delay_coarse + a_delay_coarse;
	fine_elements = __aeabi_uidiv((g_delay_fine + a_delay_fine), 10);

	/* --- c:  If Fine element is > 22, re-calculate Coarse and Fine elements --- */

	if (fine_elements > 22) {
		total_delay = coarse_elements * cdpe + fine_elements * fdpe;
		coarse_elements = __aeabi_uidiv(total_delay, cdpe);
		fine_elements = __aeabi_uidiv((total_delay % cdpe), fdpe);
	}

	/* --- d:e:  Convert and return the value of  Coarse and Fine elements --- */
	reg_val = ((coarse_elements & 0x1F) << 5) | (fine_elements & 0x1F);

	return reg_val;
}


/*
 * Do the manual IO delay sequence.
 */
 
static void do_manual_iodelay(dra7xx_io_delay_t *io_dly)
{
	unsigned refclk, dly_cnt, ref_cnt;
	unsigned reg_val, cdpe, fdpe;
	unsigned i = 0;
	unsigned q, r;

	/* --- 1. Compute CDPE and FDPE --- */

	refclk = in32(IODELAY_CONFIG_REG_2) & (0xFFFF);

	reg_val = in32(IODELAY_CONFIG_REG_3);
	dly_cnt = (reg_val >> 16);
	ref_cnt = (reg_val & 0xFFFF);

	if (dly_cnt) {
		/*
		 * Delay value is calculated as quotient + reminder. This is to avoid
		 * overflow and integer truncation. Orignal calculation is:
		 * cdpe = __aeabi_uidiv((10 * ref_cnt * refclk), (2 * dly_cnt * 88));
		 */
		q = 5 * (ref_cnt * refclk) / (dly_cnt * 88);
		r = (10 * ((ref_cnt * refclk) % (dly_cnt * 88))) / (2 * dly_cnt * 88);
		cdpe =  q + r;
	} else {
		ser_putstr("CDPE calculation failed\n");
	}

	reg_val = in32(IODELAY_CONFIG_REG_4);
	dly_cnt = (reg_val >> 16);
	ref_cnt = (reg_val & 0xFFFF);

	if (dly_cnt) {
		/*
		 * Delay value is calculated as quotient + reminder. This is to avoid
		 * overflow and integer truncation. Orignal calculation is:
		 * fdpe = __aeabi_uidiv((10 * ref_cnt * refclk), (2 * dly_cnt * 264));
		 */
		q = 5 * (ref_cnt * refclk) / (dly_cnt * 264);
		r = (10 * ((ref_cnt * refclk) % (dly_cnt * 264))) / (2 * dly_cnt * 264);
		fdpe =  q + r;
	} else {
		ser_putstr("FDPE calculation failed\n");
	}

	/* --- 2. For each pad require Manual IO timing mode, do the calculate the value required  --- */
	while (io_dly[i].addr) {
		reg_val = calculate_manual_io_timing_mode(io_dly[i].a_dly, io_dly[i].g_dly, cdpe, fdpe);
		out32(io_dly[i].addr, CFG_IO_DELAY_ACCESS_PATTERN | CFG_IO_DELAY_LOCK_MASK | reg_val);
		i++;
	}

	return;
}


/*
 * Recalibration of IO Delay.
 * After adjusting the AVS voltage for CORE voltage domain, an IO Delay Recalibration Sequence
 * is to be followed to ensure device IO timings are met.
 * IO Delay recaliberation sequence is as mentioned in the DRA7XX TRM Chapter "Control Module"
 */
 
void recalibrate_io_delay(void)
{
	unsigned temp;

	/* --- 1. Do AVS voltage for VDD_CORE voltage domain --- */

	/* --- 2. Unlock the global lock to write to the MMRs  ---*/

	out32(IODELAY_CONFIG_REG_8, CFG_IO_DELAY_UNLOCK_KEY);
 
	/* --- 3. Perform IO Delay Calibration --- */

	/* Set the refclk of IODELATCONFIG module */
	temp = in32(IODELAY_CONFIG_REG_2) & ~(0xFFFF);
	temp |= 0x2EF; /* L4_ICLK(133MHz) in ps divided by 10) */
	out32(IODELAY_CONFIG_REG_2, temp);
	/* Initiate the calibration */
	sr32(IODELAY_CONFIG_REG_0, 0, 1, 0x1);
	/* Poll for calibration to be completed */
	if (!wait_for_match(1 << 0, 0, IODELAY_CONFIG_REG_0, LDELAY)) {
		ser_putstr("Perform IO Delay Calibration failed\n");
	}

	/* --- 4. Isolation of device IOs --- */

	/* Write 1 to the ISOCLK_OVERRIDE bit */
	sr32(DRA72X_PRM_BASE + PRM_IO_PMCTRL, 0, 1, 0x1);
	/* Poll for ISOCLK_STATUS bit to read 1*/
	if (!wait_for_match(1 << 1, 1 << 1, DRA72X_PRM_BASE + PRM_IO_PMCTRL, LDELAY)) {
		ser_putstr("Isolation of device IOs failed\n");
	}

	/*
	 * Isolate all the IO. Do dummy read to
	 * ensure t > 10ns between two steps
	 */
	sr32(DRA72X_CTRL_CORE_BASE + CTRL_CORE_SMA_SW_0, 3, 1, 0x1);
	in32(DRA72X_CTRL_CORE_BASE + CTRL_CORE_SMA_SW_0);

	/* Write 0 to the ISOCLK_OVERRIDE bit */
 	sr32(DRA72X_PRM_BASE + PRM_IO_PMCTRL, 0, 1, 0x0);
	/* Poll for ISOCLK_STATUS bit to read 0*/
	if (!wait_for_match(1 << 1, 0 << 1, DRA72X_PRM_BASE + PRM_IO_PMCTRL, LDELAY)) {
		ser_putstr("Isolation of device IOs failed\n");
	}

	/* --- 5. Update the delay mechanism --- */

	/* Write 1 to ROM_READ  to initiate reload of calibrated delay values */
	sr32(IODELAY_CONFIG_REG_0, 1, 1, 0x1);
	/* Poll for ROM_READ bit to read 0 indicating reload is complete*/
	if (!wait_for_match(1 << 1, 0 << 1, IODELAY_CONFIG_REG_0, LDELAY)) {
		ser_putstr("Update delay mechanism failed\n");
	}

	/* --- 6. Configure the Mux settings --- */

	init_pinmux();

	/* --- 7. Configure Manual IO timing modes --- */
 
	do_manual_iodelay(io_delay_dp);

	/* --- 8. Deisolation of device IOs --- */

	/* Write 1 to the ISOCLK_OVERRIDE bit */
	sr32(DRA72X_PRM_BASE + PRM_IO_PMCTRL, 0, 1, 0x1);
	/* Poll for ISOCLK_STATUS bit to read 1*/
	if (!wait_for_match(1 << 1, 1 << 1, DRA72X_PRM_BASE + PRM_IO_PMCTRL, LDELAY)) {
		ser_putstr("Deisolation of device IOs failed\n");
	}
 
	/*
	 * de-Isolate all the IO. Do dummy read to
	 * ensure t > 10ns between two steps
	 */
	sr32(DRA72X_CTRL_CORE_BASE + CTRL_CORE_SMA_SW_0, 3, 1, 0x0);
	in32(DRA72X_CTRL_CORE_BASE + CTRL_CORE_SMA_SW_0);

	/* Write 0 to the ISOCLK_OVERRIDE bit */
	sr32(DRA72X_PRM_BASE + PRM_IO_PMCTRL, 0, 1, 0x0);
	/* Poll for ISOCLK_STATUS bit to read 0*/
	if (!wait_for_match(1 << 1, 0 << 1, DRA72X_PRM_BASE + PRM_IO_PMCTRL, LDELAY)) {
		ser_putstr("Deisolation of device IOs failed\n");
	}

	/* --- 9: Lock the global lock to write to the MMRs ---*/

	out32(IODELAY_CONFIG_REG_8, CFG_IO_DELAY_LOCK_KEY);
}

 
 
#if defined(__QNXNTO__) && defined(__USESRCVERSION)
#include <sys/srcversion.h>
__SRCVERSION("$URL: http://svn.ott.qnx.com/product/branches/6.6.0/trunk/hardware/ipl/boards/dra72x/calibration_iodelay.c $ $Rev: 779169 $")
#endif
