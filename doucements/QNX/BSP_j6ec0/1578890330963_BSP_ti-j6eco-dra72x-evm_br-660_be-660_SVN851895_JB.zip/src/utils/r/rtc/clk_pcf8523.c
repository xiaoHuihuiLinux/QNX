/*
 * $QNXLicenseC:
 * Copyright 2017, QNX Software Systems.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"). You
 * may not reproduce, modify or distribute this software except in
 * compliance with the License. You may obtain a copy of the License
 * at: http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OF ANY KIND, either express or implied.
 *
 * This file may contain contributions from others, either as
 * contributors under the License or as licensors under other terms.
 * Please review this entire file for other proprietary rights or license
 * notices, as well as the QNX Development Suite License Guide at
 * http://licensing.qnx.com/license-guide/ for other information.
 * $
 */
#include "rtc.h"
#include <time.h>
#include <fcntl.h>
#include <hw/i2c.h>
#include <unix.h>

/*
 * NXP PCF8523 Serial Access Timekeeper
 */
#define PCF8523_CTRL1_REG      0x00
#define PCF8523_CTRL2_REG      0x01
#define PCF8523_CTRL3_REG      0x02

#define PCF8523_SEC_REG        0x03     /* Seconds 0-59 */
#define PCF8523_MIN_REG        0x04     /* Minutes 0-59 */
#define PCF8523_HR_REG         0x05     /* 0-23 in 24hr time */
#define PCF8523_DAY_REG        0x06     /* 1-31 */
#define PCF8523_DW_REG         0x07     /* 0-6 */
#define PCF8523_MO_REG         0x08     /* 1-12 */
#define PCF8523_YR_REG         0x09     /* 0-99 */

#define PCF8523_ALRM_MIN_REG   0x0A     /* 0-59 */
#define PCF8523_ALRM_HR_REG    0x0B     /* 0-23 in 24hr mode */
#define PCF8523_ALRM_DAY_REG   0x0C     /* 1-31 */
#define PCF8523_ALRM_DW_REG    0x0D     /* 0-6 */

#define PCF8523_OFFSET_REG     0x0E

#define PCF8523_TMR_CLKOUT_CTRL_REG 0x0F
#define PCF8523_TMR_A_FREQ_CTRL_REG 0x10
#define PCF8523_TMR_A_REG           0x11
#define PCF8523_TMR_B_FREQ_CTRL_REG 0x12
#define PCF8523_TMR_B_REG           0x13

#define PCF8523_CTRL1_CAP_SEL       0x80    /* 0 = 7pF, 1 = 12.5pF */
#define PCF8523_CTRL1_STOP_BIT      0x20    /* 0 = Running, 1 = Stopped */
#define PCF8523_CTRL1_RESET_CMD     0x10    /* 0 = No Reset, 1 = Cmd Reset */
#define PCF8523_CTRL1_MIL_MODE      0x08    /* 0 = Military/24hr, 1 = 12Hr */
#define PCF8523_CTRL1_SEC_INT_EN    0x04    /* 0 = Second Int Disabled, 1 = Enabled */
#define PCF8523_CTRL1_AL_INT_EN     0x02    /* 0 = Alarm Int Disabled, 1 = Enabled */
#define PCF8523_CTRL1_COR_INT_EN    0x01    /* 0 = Correction Int Disabled, 1 = Disabled */

#define PCF8523_CTRL2_WD_INT_BIT    0x80    /* 0 = Watchdog Int Not Active, 1 = Active */
#define PCF8523_CTRL2_CDTA_INT_BIT  0x40    /* 0 = Countdown Timer A Int Not Active, 1 = Active */
#define PCF8523_CTRL2_CDTB_INT_BIT  0x20    /* 0 = Countdown Timer B Int Not Active, 1 = Active */
#define PCF8523_CTRL2_SEC_INT_BIT   0x10    /* 0 = Second Int Not Active, 1 = Active */
#define PCF8523_CTRL2_AL_INT_BIT    0x08    /* 0 = Alarm Int Not Active, 1 = Active */
#define PCF8523_CTRL2_WD_INT_EN     0x04    /* 0 = Watchdog Int Disabled, 1 = Enabled */
#define PCF8523_CTRL2_CDTA_INT_EN   0x02    /* 0 = Countdown Timer A Int Disabled, 1 = Enabled */
#define PCF8523_CTRL2_CDTB_INT_EN   0x01    /* 0 = Countdown Timer B Int Disabled, 1 = Enabled */

#define PCF8523_CTRL3_ON_BAT_INT_BIT    0x08    /* 0 = On Battery Int Not Active, 1 = Active */
#define PCF8523_CTRL3_LOW_BAT_INT_BIT   0x04    /* 0 = Low Battery Int Not Active, 1 = Active */
#define PCF8523_CTRL3_ON_BAT_INT_EN     0x02    /* 0 = On Battery Int Disabled, 1 = Enabled */
#define PCF8523_CTRL3_LOW_BAT_INT_EN    0x01    /* 0 = Low Battery Int Disabled 1 = Enabled */
#define PCF8523_CTRL3_PWR_MODE_MASK     0xE0    /* Power Management Configuration */
#define PCF8523_CTRL3_PWR_MODE_SEL      0x00    /* Allow RTC to use the battery and check for low battery */

#define PCF8523_SEC_REG_INTEGITY_BIT    0x80    /* 0 = Integrity is good, 1 = Integrity is not guaranteed */

#define PCF8523_I2C_ADDRESS  (0x68)   // Actually (0x68)
#define PCF8523_I2C_DEVNAME  "/dev/i2c1"

static int fd = -1;
static int integrityFailed = 0;
static int batteryVoltLow = 0;

static int
pcf8523_i2c_read(unsigned char reg, unsigned char val[], unsigned char num)
{
    iov_t           siov[2], riov[2];
    i2c_sendrecv_t  hdr;

    hdr.slave.addr = PCF8523_I2C_ADDRESS;
    hdr.slave.fmt = I2C_ADDRFMT_7BIT;
    hdr.send_len = 1;
    hdr.recv_len = num;
    hdr.stop = 1;

    SETIOV(&siov[0], &hdr, sizeof(hdr));
    SETIOV(&siov[1], &reg, sizeof(reg));

    SETIOV(&riov[0], &hdr, sizeof(hdr));
    SETIOV(&riov[1], val, num);

    return devctlv(fd, DCMD_I2C_SENDRECV, 2, 2, siov, riov, NULL);
}

static int
pcf8523_i2c_write(unsigned char reg, unsigned char val[], unsigned char num)
{
    iov_t           siov[3];
    i2c_send_t      hdr;

    hdr.slave.addr = PCF8523_I2C_ADDRESS;
    hdr.slave.fmt = I2C_ADDRFMT_7BIT;
    hdr.len = num + 1;
    hdr.stop = 1;

    SETIOV(&siov[0], &hdr, sizeof(hdr));
    SETIOV(&siov[1], &reg, sizeof(reg));
    SETIOV(&siov[2], val, num);

    return devctlv(fd, DCMD_I2C_SEND, 3, 0, siov, NULL, NULL);
}

static int
pcf8523_check_rtc_status(void)
{
    unsigned char   softResetNeeded = 0;
    unsigned char   readDate[PCF8523_TMR_B_REG + 1];  // Holds the data from second register to control register
    unsigned char   writeData[PCF8523_TMR_B_REG + 1];

    /* Check the current state of the RTC */
    pcf8523_i2c_read(PCF8523_CTRL1_REG, readDate, PCF8523_TMR_B_REG + 1);

    /* Check battery status */
    if (readDate[PCF8523_CTRL3_REG] & PCF8523_CTRL3_LOW_BAT_INT_BIT)
    {
        batteryVoltLow = 1;
    }

    if (  (readDate[PCF8523_CTRL1_REG] & PCF8523_CTRL1_STOP_BIT)
        ||(readDate[PCF8523_SEC_REG] & PCF8523_SEC_REG_INTEGITY_BIT)
       )
    {
        integrityFailed = 1;    /* Time can't be trusted */
    }
    else if (  (readDate[PCF8523_CTRL1_REG] != PCF8523_CTRL1_CAP_SEL)   /* Only bit that should be set is the 12.5pF */
             ||(readDate[PCF8523_CTRL2_REG] != 0)   /* None of the extra counters or timers should be enabled */
             ||((readDate[PCF8523_CTRL3_REG] & PCF8523_CTRL3_PWR_MODE_MASK) != PCF8523_CTRL3_PWR_MODE_SEL)
             ||((readDate[PCF8523_CTRL3_REG] & (PCF8523_CTRL3_ON_BAT_INT_EN | PCF8523_CTRL3_LOW_BAT_INT_EN | PCF8523_CTRL3_ON_BAT_INT_BIT)) != 0)
             ||(readDate[PCF8523_OFFSET_REG] != 0)  /* There should be no offset adjustment */
             ||(readDate[PCF8523_TMR_CLKOUT_CTRL_REG] != 0) /* Timer A & B should be disabled */
            )
    {
        /* Some of the settings are not what was expected, so we need to readjust the setting
        // but shouldn't have an affect on the actual time.
        */
        softResetNeeded = 1;
    }

    if (  (softResetNeeded)
        ||(integrityFailed)
       )
    {
        /* We the need to reset the config register(s) */
        /* Set the control and status information */
        writeData[0] = PCF8523_CTRL1_CAP_SEL;   /* For Control 1, only bit that should be set is the 12.5pF */
        writeData[1] =  0;   /* For Control 2, none of the extra counters or timers should be enabled */
        writeData[2] = PCF8523_CTRL3_PWR_MODE_SEL;  // For Control 3, only bits that we need to make sure are set is the power modde */
        pcf8523_i2c_write(PCF8523_CTRL1_REG, writeData, 3);

        writeData[0] = 0;  /* For Offset Register, there should be no offset adjustment */
        writeData[1] = 0;  /* For Timer Clockout Control Register, timers A & B should be disabled */
        pcf8523_i2c_write(PCF8523_OFFSET_REG, writeData, 2);

        if (integrityFailed)
        {
            /* Need to write a time to the RTC to have it start counting again.
            // We will rewrite it the time currently stored in the RTC since
            // that it only thing we got for now.
            */
            readDate[PCF8523_SEC_REG] &= (~PCF8523_SEC_REG_INTEGITY_BIT);
            pcf8523_i2c_write(PCF8523_SEC_REG, &readDate[PCF8523_SEC_REG], (PCF8523_YR_REG - PCF8523_CTRL3_REG));

        }
    }

    return (0);
}

int
RTCFUNC(init,pcf8523)(struct chip_loc *chip, char *argv[])
{
    unsigned char date[PCF8523_YR_REG + 1];

    fd = open((argv && argv[0] && argv[0][0])?
            argv[0]: PCF8523_I2C_DEVNAME, O_RDWR);
    if (fd < 0) {
        fprintf(stderr, "Unable to open I2C device\n");
        return -1;
    }

    pcf8523_check_rtc_status();

    if (integrityFailed)
    {
        /* Set the date and time to a default */
        date[PCF8523_SEC_REG] = 0x00;
        date[PCF8523_MIN_REG] = 0x00;
        date[PCF8523_HR_REG]  = 0x00;
        date[PCF8523_DAY_REG] = 0x16;
        date[PCF8523_MO_REG]  = 0x06;
        date[PCF8523_YR_REG]  = 0x17;
        date[PCF8523_DW_REG]  = 0x06;   /* Day of week */

        pcf8523_i2c_write(PCF8523_SEC_REG, &date[PCF8523_SEC_REG], 7);
    }

    return 0;
}

int
RTCFUNC(get,pcf8523)(struct tm *tm, int cent_reg)
{
    unsigned char   softResetNeeded = 0;
    unsigned char   date[PCF8523_TMR_B_REG + 1];  /* Holds the data from second register to control register */
    unsigned char   writeData[PCF8523_TMR_B_REG + 1];

    /* Check the current state of the RTC */
    pcf8523_i2c_read(PCF8523_CTRL1_REG, date, PCF8523_TMR_B_REG + 1);

    /* No battery status feedback with this RTC */
    if (date[PCF8523_CTRL3_REG] & PCF8523_CTRL3_LOW_BAT_INT_BIT)
    {
        batteryVoltLow = 1;
    }

    if (  (date[PCF8523_CTRL1_REG] & PCF8523_CTRL1_STOP_BIT)
        ||(date[PCF8523_SEC_REG] & PCF8523_SEC_REG_INTEGITY_BIT)
       )

    {
        integrityFailed = 1;    /* Time can't be trusted */
    }

    tm->tm_sec  = BCD2BIN( (date[PCF8523_SEC_REG] & ~PCF8523_SEC_REG_INTEGITY_BIT) );;
    tm->tm_min  = BCD2BIN(date[PCF8523_MIN_REG]);
    tm->tm_hour = BCD2BIN( date[PCF8523_HR_REG] );
    tm->tm_mday = BCD2BIN(date[PCF8523_DAY_REG]);
    tm->tm_mon  = (BCD2BIN(date[PCF8523_MO_REG])) - 1;  /* OS expects the month to start with 0 */
    tm->tm_year = BCD2BIN(date[PCF8523_YR_REG]);
    tm->tm_wday = BCD2BIN( date[PCF8523_DW_REG] );

    tm->tm_year += 100;

    if (  (date[PCF8523_CTRL1_REG] & PCF8523_CTRL1_STOP_BIT)
        ||(date[PCF8523_SEC_REG] & PCF8523_SEC_REG_INTEGITY_BIT)
       )
    {
        integrityFailed = 1;    /* Time can't be trusted */
    }
    else if (  (date[PCF8523_CTRL1_REG] != PCF8523_CTRL1_CAP_SEL)   /* Only bit that should be set is the 12.5pF */
             ||(date[PCF8523_CTRL2_REG] != 0)   /* None of the extra counters or timers should be enabled */
             ||((date[PCF8523_CTRL3_REG] & PCF8523_CTRL3_PWR_MODE_MASK) != PCF8523_CTRL3_PWR_MODE_SEL)
             ||((date[PCF8523_CTRL3_REG] & (PCF8523_CTRL3_ON_BAT_INT_EN | PCF8523_CTRL3_LOW_BAT_INT_EN | PCF8523_CTRL3_ON_BAT_INT_BIT)) != 0)
             ||(date[PCF8523_OFFSET_REG] != 0)  /* There should be no offset adjustment */
             ||(date[PCF8523_TMR_CLKOUT_CTRL_REG] != 0) /* Timer A & B should be disabled */
            )
    {
        /* Some of the settings are not what was expected, so we need to re-adjust the setting
        // but shouldn't have an affect on the actual time.
        */
        softResetNeeded = 1;
    }

    if (  (softResetNeeded)
        ||(integrityFailed)
       )
    {
        /* We the need to reset the config register(s) */
        /* Set the control and status information */
        writeData[0] = PCF8523_CTRL1_CAP_SEL;   /* For Control 1, only bit that should be set is the 12.5pF */
        writeData[1] =  0;   /* For Control 2, none of the extra counters or timers should be enabled */
        writeData[2] = PCF8523_CTRL3_PWR_MODE_SEL;  // For Control 3, only bits that we need to make sure are set is the power modde */
        pcf8523_i2c_write(PCF8523_CTRL1_REG, writeData, 3);

        writeData[0] = 0;  /* For Offset Register, there should be no offset adjustment */
        writeData[1] = 0;  /* For Timer Clockout Control Register, timers A & B should be disabled */
        pcf8523_i2c_write(PCF8523_OFFSET_REG, writeData, 2);

        if (integrityFailed)
        {
            /* Need to write a time to the RTC to have it start counting again.
             * We will rewrite the time that is currently stored in the RTC since
             * that it only thing we got for now.
            */
            date[PCF8523_SEC_REG] &= (~PCF8523_SEC_REG_INTEGITY_BIT);
            pcf8523_i2c_write(PCF8523_SEC_REG, &date[PCF8523_SEC_REG], (PCF8523_YR_REG - PCF8523_CTRL3_REG) );
        }
    }

    return(0);
}

int
RTCFUNC(set,pcf8523)(struct tm *tm, int cent_reg)
{
    unsigned char   date[PCF8523_YR_REG+1];

    pcf8523_check_rtc_status();

    date[PCF8523_SEC_REG]   = BIN2BCD(tm->tm_sec); /* implicitly clears validity bit */
    date[PCF8523_MIN_REG]   = BIN2BCD(tm->tm_min);
    date[PCF8523_HR_REG]    = BIN2BCD(tm->tm_hour);
    date[PCF8523_DAY_REG]   = BIN2BCD(tm->tm_mday);
    date[PCF8523_MO_REG]    = BIN2BCD( (tm->tm_mon + 1) );     /* RTC expects the month to start with 1 */
    date[PCF8523_YR_REG]    = BIN2BCD( (tm->tm_year % 100) );
    date[PCF8523_DW_REG]    = BIN2BCD( tm->tm_wday );

    pcf8523_i2c_write(PCF8523_SEC_REG, &date[PCF8523_SEC_REG], (PCF8523_YR_REG - PCF8523_CTRL3_REG));
    integrityFailed = 0;    /* The time was just set so it has to be accurate. */

    return(0);
}

int
RTCFUNC(batt,pcf8523)(int *status) {
    if (batteryVoltLow) {
        *status = RTC_BATT_STATUS_LOW;
    } else {
        *status = RTC_BATT_STATUS_OK;
    }

    return EOK;
}

int
RTCFUNC(verify,pcf8523)(int *status) {
    if (integrityFailed) {
        *status = RTC_STATUS_ERROR;
    } else {
        *status = RTC_STATUS_OK;
    }

    return EOK;
}

#if defined(__QNXNTO__) && defined(__USESRCVERSION)
#include <sys/srcversion.h>
__SRCVERSION("$URL: http://svn.ott.qnx.com/product/branches/6.6.0/trunk/utils/r/rtc/clk_pcf8523.c $ $Rev: 845772 $")
#endif
