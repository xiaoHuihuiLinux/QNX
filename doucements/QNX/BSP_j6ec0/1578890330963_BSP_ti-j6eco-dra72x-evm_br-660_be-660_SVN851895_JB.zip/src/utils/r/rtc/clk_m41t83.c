/*
 * $QNXLicenseC:
 * Copyright 2017, QNX Software Systems.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"). You
 * may not reproduce, modify or distribute this software except in
 * compliance with the License. You may obtain a copy of the License
 * at: http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OF ANY KIND, either express or implied.
 *
 * This file may contain contributions from others, either as
 * contributors under the License or as licensors under other terms.
 * Please review this entire file for other proprietary rights or license
 * notices, as well as the QNX Development Suite License Guide at
 * http://licensing.qnx.com/license-guide/ for other information.
 * $
 */
#include "rtc.h"
#include <time.h>
#include <fcntl.h>
#include <hw/i2c.h>
#include <unix.h>

/*
 * STM M41T83 Serial I2C bus real-time clock
 *
 */

#define BIT(x)              (1 << x)
#define M41T83_REG_SSEC     0x00
#define M41T83_REG_SEC      0x01
#define M41T83_REG_MIN      0x02
#define M41T83_REG_HOUR     0x03
#define M41T83_REG_WDAY     0x04
#define M41T83_REG_DAY      0x05
#define M41T83_REG_MON      0x06
#define M41T83_REG_YEAR     0x07
#define M41T83_REG_ALARM_MON    0x0a
#define M41T83_REG_ALARM_DAY    0x0b
#define M41T83_REG_ALARM_HOUR   0x0c
#define M41T83_REG_ALARM_MIN    0x0d
#define M41T83_REG_ALARM_SEC    0x0e
#define M41T83_REG_FLAGS    0x0f
#define M41T83_REG_SQW      0x13


#define M41T83_DATETIME_REG_SIZE    (M41T83_REG_YEAR + 1)
#define M41T83_ALARM_REG_SIZE   \
    (M41T83_REG_ALARM_SEC + 1 - M41T83_REG_ALARM_MON)

#define M41T83_SEC_ST               BIT(7)  /* ST: Stop Bit */
#define M41T83_ALMON_AFE            BIT(7)  /* AFE: AF Enable Bit */
#define M41T83_ALMON_SQWE           BIT(6)  /* SQWE: SQW Enable Bit */
#define M41T83_ALHOUR_HT            BIT(6)  /* HT: Halt Update Bit */
#define M41T83_FLAGS_OF             BIT(2)  /* OF: Oscillator Failure Bit */
#define M41T83_FLAGS_AF             BIT(6)  /* AF: Alarm Flag Bit */
#define M41T83_FLAGS_BATT_LOW       BIT(4)  /* BL: Battery Low Bit */
#define M41T83_WATCHDOG_RB2         BIT(7)  /* RB: Watchdog resolution */
#define M41T83_WATCHDOG_RB1         BIT(1)  /* RB: Watchdog resolution */
#define M41T83_WATCHDOG_RB0         BIT(0)  /* RB: Watchdog resolution */


#define M41T83_HT_CHECK            BIT(0)
#define M41T83_BATT_CHECK          BIT(1)
#define M41T83_OSC_CHECK           BIT(2)
#define M41T83_OSC_RESET_ALLOWED   BIT(3)

#define M41T83_I2C_ADDRESS  (0xD0 >> 1)
#define M41T83_I2C_DEVNAME  "/dev/i2c0"


static int fd = -1;
static int
m41t83_i2c_read(unsigned char reg, unsigned char val[], unsigned char num)
{
    iov_t           siov[2], riov[2];
    i2c_sendrecv_t  hdr;

    hdr.slave.addr = M41T83_I2C_ADDRESS;
    hdr.slave.fmt = I2C_ADDRFMT_7BIT;
    hdr.send_len = 1;
    hdr.recv_len = num;
    hdr.stop = 1;

    SETIOV(&siov[0], &hdr, sizeof(hdr));
    SETIOV(&siov[1], &reg, sizeof(reg));

    SETIOV(&riov[0], &hdr, sizeof(hdr));
    SETIOV(&riov[1], val, num);

    return devctlv(fd, DCMD_I2C_SENDRECV, 2, 2, siov, riov, NULL);
}

static int
m41t83_i2c_write(unsigned char reg, unsigned char val[], unsigned char num)
{
    iov_t           siov[3];
    i2c_send_t      hdr;

    hdr.slave.addr = M41T83_I2C_ADDRESS;
    hdr.slave.fmt = I2C_ADDRFMT_7BIT;
    hdr.len = num + 1;
    hdr.stop = 1;

    SETIOV(&siov[0], &hdr, sizeof(hdr));
    SETIOV(&siov[1], &reg, sizeof(reg));
    SETIOV(&siov[2], val, num);

    return devctlv(fd, DCMD_I2C_SEND, 3, 0, siov, NULL, NULL);
}

static int check_rtc_status (int *is_osc_stopped, int flags)
{
    unsigned char   write_data, reg_flags, reg_sec, reg_alhour;

    /* check HT bit */
    if (flags & M41T83_HT_CHECK) {
        if (m41t83_i2c_read(M41T83_REG_ALARM_HOUR, &reg_alhour, 1)) {
            fprintf(stderr, "%s: Error reading M41T83_REG_ALARM_HOUR \n", __func__);
            return -1;
        }
        if (reg_alhour & M41T83_ALHOUR_HT) {
            write_data = reg_alhour &  ~M41T83_ALHOUR_HT;
            if (m41t83_i2c_write(M41T83_REG_ALARM_HOUR, &write_data, 1)) {
                fprintf(stderr, "%s: Error writting M41T83_REG_ALARM_HOUR \n", __func__);
                return -1;
            }
        }
    }

    if ((flags & M41T83_BATT_CHECK) || (flags & M41T83_OSC_CHECK)) {
        if (m41t83_i2c_read(M41T83_REG_FLAGS, &reg_flags, 1)) {
            fprintf(stderr, "%s: Error reading M41T83_REG_FLAGS \n", __func__);
            return -1;
        }
    }

    if (flags & M41T83_BATT_CHECK) {
        /* check battery level */
        if (reg_flags & M41T83_FLAGS_BATT_LOW){
            /* Not critical, but need to draw the user attention */
            fprintf(stderr, "%s: RTC battery level very low!\n", __func__);
        }
    }

    if (flags & M41T83_OSC_CHECK) {
        if (m41t83_i2c_read(M41T83_REG_SEC, &reg_sec, 1)) {
            fprintf(stderr, "%s: Error reading M41T83_REG_SEC \n", __func__);
            return -1;
        }

        /* check if osillator is stopped */
        if ((reg_flags & M41T83_FLAGS_OF) || (reg_sec & M41T83_SEC_ST)) {
            *is_osc_stopped = 1;
            if (flags & M41T83_OSC_RESET_ALLOWED) {
                /* Set ST bit to 1*/
                write_data = reg_sec | M41T83_SEC_ST;
                if (m41t83_i2c_write(M41T83_REG_SEC, &write_data, 1)) {
                    fprintf(stderr, "%s: Error writting M41T83_REG_SEC \n", __func__);
                    return -1;
                }

                /* Clear ST bit immediately */
                write_data = reg_sec & ~M41T83_SEC_ST;
                if (m41t83_i2c_write(M41T83_REG_SEC, &write_data, 1)) {
                    fprintf(stderr, "%s: Error writting M41T83_REG_SEC \n", __func__);
                    return -1;
                }
                /* Need to wait at lease 4s before attemping to reset OF bit */
                delay(5*1000);

                write_data = reg_flags & ~M41T83_FLAGS_OF;
                if (m41t83_i2c_write(M41T83_REG_FLAGS, &write_data, 1)) {
                    fprintf(stderr, "%s: Error writting M41T83_REG_SEC \n", __func__);
                    return -1;
                }
            }
        }
    }
    return 0;
}

int
RTCFUNC(init,m41t83)(struct chip_loc *chip, char *argv[])
{
    int is_osc_stopped = 0;


    fd = open((argv && argv[0] && argv[0][0])?
            argv[0]: M41T83_I2C_DEVNAME, O_RDWR);
    if (fd < 0) {
        fprintf(stderr, "%s: Unable to open I2C device\n", __func__);
        return -1;
    }

    if (check_rtc_status(&is_osc_stopped,
                    M41T83_HT_CHECK | M41T83_BATT_CHECK |
                    M41T83_OSC_CHECK|M41T83_OSC_RESET_ALLOWED)) {
        return -1;
    }

    return 0;
}

int
RTCFUNC(get,m41t83)(struct tm *tm, int cent_reg)
{
    unsigned char   date[8];  // Holds the data from sub-second register to flags register
    unsigned char   century;
    int             is_osc_stopped = 0;

    if (check_rtc_status(&is_osc_stopped, M41T83_OSC_CHECK)) {
        return -1;
    }
    /* If oscillator is failed, date is invalid */
    if (is_osc_stopped) {
        fprintf(stderr, "%s: Oscillator failure, data is invalid \n", __func__);
        return -1;
    }

    if (m41t83_i2c_read(M41T83_REG_SSEC, date, sizeof(date))) {
        fprintf(stderr, "%s: Error reading M41T83_REG_SSEC \n", __func__);
        return -1;
    }

    tm->tm_sec  = BCD2BIN(date[M41T83_REG_SEC] & 0x7f);
    tm->tm_min  = BCD2BIN(date[M41T83_REG_MIN] & 0x7f);
    tm->tm_hour = BCD2BIN(date[M41T83_REG_HOUR] & 0x3f);
    tm->tm_wday = BCD2BIN(date[M41T83_REG_WDAY] & 0x07);
    tm->tm_mday =  BCD2BIN(date[M41T83_REG_DAY] & 0xf);
    tm->tm_mon  = BCD2BIN(date[M41T83_REG_MON] & 0x1f) -1 ;
    tm->tm_year = BCD2BIN(date[M41T83_REG_YEAR]);

    if (verbose > 4) {
        fprintf(stderr, "%s: tm_sec=%d, tm_min=%d, tm_hour=%d, tm_mday=%d, tm_wday=%d, tm_mon=%d, tm_year=%d \n",
                                                        __func__,
                                                        tm->tm_sec,
                                                        tm->tm_min,
                                                        tm->tm_hour,
                                                        tm->tm_mday,
                                                        tm->tm_wday,
                                                        tm->tm_mon,
                                                        tm->tm_year);
        int i;
        for (i = 0; i < sizeof(date); i++) {
            fprintf(stderr, "[%d]:%#x ", i, date[i]);
        }
        fprintf(stderr, "\n");
    }

    century = (date[M41T83_REG_HOUR] >> 6) & 0x03;
    tm->tm_year += (century + 1) * 100;

    return(0);
}

int
RTCFUNC(set,m41t83)(struct tm *tm, int cent_reg)
{

    unsigned char  date[8];
    char   century;

    if (tm->tm_year < 100 || tm->tm_year > 399) {
        fprintf(stderr, "%s:invalid year:%d \n", __func__, tm->tm_year + 1900);
        return -1;
    }

    date[M41T83_REG_SSEC]  = 0;
    date[M41T83_REG_SEC]   = BIN2BCD(tm->tm_sec);
    date[M41T83_REG_MIN]   = BIN2BCD(tm->tm_min);
    date[M41T83_REG_HOUR]  = BIN2BCD(tm->tm_hour);
    date[M41T83_REG_WDAY]  = BIN2BCD(tm->tm_wday);
    date[M41T83_REG_DAY]   = BIN2BCD(tm->tm_mday);
    date[M41T83_REG_MON]   = BIN2BCD(tm->tm_mon + 1);
    date[M41T83_REG_YEAR]  = BIN2BCD(tm->tm_year % 100);

    century = tm->tm_year / 100 - 1;
    /* 2bits counter(CB0,CB1) to hold the century information */
    date[M41T83_REG_HOUR] |= (century & 0x03) << 6;
    if (verbose > 4) {
        fprintf(stderr, "%s: tm_sec=%d, tm_min=%d, tm_hour=%d, tm_mday=%d, tm_wday=%d, tm_mon=%d, tm_year=%d \n",
                                                        __func__,
                                                        tm->tm_sec,
                                                        tm->tm_min,
                                                        tm->tm_hour,
                                                        tm->tm_mday,
                                                        tm->tm_wday,
                                                        tm->tm_mon,
                                                        tm->tm_year);
        int i;
        for (i = 0; i < sizeof(date); i++) {
            fprintf(stderr, "[%d]:%#x ", i, date[i]);
        }
        fprintf(stderr, "\n");
    }
    if (m41t83_i2c_write(M41T83_REG_SSEC, date, sizeof(date))) {
        fprintf(stderr, "%s: Error writting M41T83_REG_SSEC \n", __func__);
        return -1;
    }

    return(0);
}

#if defined(__QNXNTO__) && defined(__USESRCVERSION)
#include <sys/srcversion.h>
__SRCVERSION("$URL: http://svn.ott.qnx.com/product/branches/6.6.0/trunk/utils/r/rtc/clk_m41t83.c $ $Rev: 836770 $")
#endif
