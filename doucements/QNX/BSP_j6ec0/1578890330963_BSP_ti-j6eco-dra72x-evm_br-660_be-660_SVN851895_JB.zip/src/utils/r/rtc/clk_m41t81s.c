/*
 * $QNXLicenseC:
 * Copyright 2017, QNX Software Systems.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"). You
 * may not reproduce, modify or distribute this software except in
 * compliance with the License. You may obtain a copy of the License
 * at: http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OF ANY KIND, either express or implied.
 *
 * This file may contain contributions from others, either as
 * contributors under the License or as licensors under other terms.
 * Please review this entire file for other proprietary rights or license
 * notices, as well as the QNX Development Suite License Guide at
 * http://licensing.qnx.com/license-guide/ for other information.
 * $
 */
#include "rtc.h"
#include <time.h>
#include <fcntl.h>
#include <hw/i2c.h>
#include <unix.h>

/*
 * STM M41T81 Serial Access Timekeeper
 *    Naming function m41t81s_xxxxx to avoid conflict with MIPs version for this chip
 */
#define M41T81_SEC_OFFSET   1
#define M41T81_SSEC         0   /* 0-0.99 */
#define M41T81_SEC          1   /* 00-59 */
#define M41T81_MIN          2   /* 00-59 */
#define M41T81_HOUR         3   /* 0-1/00-23 */
#define M41T81_DAY          4   /* 01-07 */
#define M41T81_DATE         5   /* 01-31 */
#define M41T81_MONTH        6   /* 01-12 */
#define M41T81_YEAR         7   /* 00-99 */
#define M41T81_CALB         8   /* Calibration */
#define M41T81_WD           9   /* Watchdog */
#define M41T81_AL_MONTH     10  /* Alarm Month */
#define M41T81_AL_DATE      11  /* Alarm Date */
#define M41T81_AL_HOUR      12  /* Alarm Hour */
#define M41T81_AL_MIN       13  /* Alarm Minute */
#define M41T81_AL_SEC       14  /* Alarm Seconds */
#define M41T81_FLAGS        15  /* Status Flags */

#define M41T81_SEC_ST       0x80    /* oscillator Stop bit */
#define M41T81_HOUR_CEB     0x80    /* Century Enable bit */
#define M41T81_HOUR_CB      0x40    /* Century bit */
#define M41T81_AL_HOUR_HTB  0x40    /* Register Update Halt Bit */
#define M41T81_FLAGS_OFB    0x04    /* Oscillator Failed bit */
#define M41T81_FLAGS_BLB    0x10    /* Battery Voltage Low bit */

#define M41T81_I2C_ADDRESS  (0xD0 >> 1)
#define M41T81_I2C_DEVNAME  "/dev/i2c0"

/*
 * Century bit convention:
 * 0 = 2000
 * 1 = 1900 OR 2100
 *  if (year < 70)
 *      2100
 *  else
 *      1900
 */

static int fd = -1;
static int integrityFailed = 1;
static int batteryVoltLow = 0;

static int
m41t81s_i2c_read(unsigned char reg, unsigned char val[], unsigned char num)
{
    iov_t           siov[2], riov[2];
    i2c_sendrecv_t  hdr;

    hdr.slave.addr = M41T81_I2C_ADDRESS;
    hdr.slave.fmt = I2C_ADDRFMT_7BIT;
    hdr.send_len = 1;
    hdr.recv_len = num;
    hdr.stop = 1;

    SETIOV(&siov[0], &hdr, sizeof(hdr));
    SETIOV(&siov[1], &reg, sizeof(reg));

    SETIOV(&riov[0], &hdr, sizeof(hdr));
    SETIOV(&riov[1], val, num);

    return devctlv(fd, DCMD_I2C_SENDRECV, 2, 2, siov, riov, NULL);
}

static int
m41t81s_i2c_write(unsigned char reg, unsigned char val[], unsigned char num)
{
    iov_t           siov[3];
    i2c_send_t      hdr;

    hdr.slave.addr = M41T81_I2C_ADDRESS;
    hdr.slave.fmt = I2C_ADDRFMT_7BIT;
    hdr.len = num + 1;
    hdr.stop = 1;

    SETIOV(&siov[0], &hdr, sizeof(hdr));
    SETIOV(&siov[1], &reg, sizeof(reg));
    SETIOV(&siov[2], val, num);

    return devctlv(fd, DCMD_I2C_SEND, 3, 0, siov, NULL, NULL);
}

static int
m41t81s_check_rtc_status(void)
{
    unsigned char   readDate[M41T81_FLAGS + 1];  /* Holds the data from sub-second register to flags register */
    unsigned char   writeData[2];

    /* Check the current state of the RTC */
    m41t81s_i2c_read(M41T81_SSEC, readDate, M41T81_FLAGS + 1);

    if (readDate[M41T81_FLAGS] & M41T81_FLAGS_BLB)
    {
        batteryVoltLow = 1;
    }
    else
    {
        batteryVoltLow = 0;
    }

    if (  (readDate[M41T81_FLAGS] & M41T81_FLAGS_OFB)   /* Oscillator Failed Bit */
        ||(readDate[M41T81_SEC] & M41T81_SEC_ST)        /* Oscillator Stopped Bit */
       )
    {
        integrityFailed = 1;

        /* Oscillator is not running, reset it */
        writeData[0] = readDate[M41T81_SEC] | M41T81_SEC_ST;
        writeData[1] = writeData[0] & 0x7F;
        m41t81s_i2c_write(M41T81_SEC, writeData, 2);
        nap(1000);

        /* Tell the RTC to update it's registers. */
        if (readDate[M41T81_AL_HOUR] & M41T81_AL_HOUR_HTB)
        {
            writeData[0] = 0;  /* Clears M41T81_AL_HOUR_HTB */
            m41t81s_i2c_write(M41T81_AL_HOUR, writeData, 1);
        }

        /* Clear the Oscillator Fail flag.
         * In order to do that:  First write a data and time, then
         * wait 5s, and then clear the flag.  Failure to follow
         * these steps will result in the flag not getting cleared.
         * Note:  We'll use the current date and time stored in the RTC
        */
        readDate[M41T81_SEC] &= 0x7F;       /* Clear out the stop bit */
        m41t81s_i2c_write(M41T81_SSEC, readDate, M41T81_YEAR + 1);
        nap(5000);

        writeData[0] = 0;
        m41t81s_i2c_write(M41T81_FLAGS, writeData, 1);
    }
    else
    {
        /* Next, tell the RTC to update it's registers.*/
        if (readDate[M41T81_AL_HOUR] & M41T81_AL_HOUR_HTB)
        {
            writeData[0] = 0;  /* Clears M41T81_AL_HOUR_HTB */
            m41t81s_i2c_write(M41T81_AL_HOUR, writeData, 1);
        }

        integrityFailed = 0;
    }

    return (0);
}

int
RTCFUNC(init,m41t81s)(struct chip_loc *chip, char *argv[])
{
    unsigned char date[8];

    fd = open((argv && argv[0] && argv[0][0])?
            argv[0]: M41T81_I2C_DEVNAME, O_RDWR);
    if (fd < 0) {
        fprintf(stderr, "Unable to open I2C device\n");
        return -1;
    }

    m41t81s_check_rtc_status();

    if (integrityFailed)
    {
        /* Set the date and time to a default */
        date[M41T81_SSEC] = 0x00;
        date[M41T81_SEC] = 0x00;
        date[M41T81_MIN] = 0x00;
        date[M41T81_HOUR] = 0x00;
        date[M41T81_DAY] = 0x06;
        date[M41T81_DATE] = 0x16;
        date[M41T81_MONTH] = 0x06;
        date[M41T81_YEAR] = 0x17;

        m41t81s_i2c_write(M41T81_SEC, date, M41T81_YEAR + 1);
    }

    return 0;
}

int
RTCFUNC(get,m41t81s)(struct tm *tm, int cent_reg)
{
    unsigned char   date[M41T81_FLAGS + 1];  /* Holds the data from sub-second register to flags register */
    unsigned char   dataWrite[2];
    unsigned char   century;

    m41t81s_i2c_read(M41T81_SSEC, date, M41T81_FLAGS + 1);

    tm->tm_sec  = BCD2BIN( (date[M41T81_SEC] & ~M41T81_SEC_ST) );
    tm->tm_min  = BCD2BIN(date[M41T81_MIN]);
    tm->tm_hour = BCD2BIN( (date[M41T81_HOUR] &
                            ~(M41T81_HOUR_CEB|M41T81_HOUR_CB)) );
    tm->tm_mday = BCD2BIN(date[M41T81_DATE]);
    tm->tm_mon  = BCD2BIN( (date[M41T81_MONTH] - 1) );  /*OS expects the month to start with 0 */
    tm->tm_year = BCD2BIN(date[M41T81_YEAR]);
    tm->tm_wday = BCD2BIN( (date[M41T81_DAY] - 1) );    /*OS expects the day of the week to start with 0 */

    if (date[M41T81_HOUR] & M41T81_HOUR_CEB) {
        century = date[M41T81_HOUR] & M41T81_HOUR_CB;
        if (century) {
            if (tm->tm_year < 70)
                tm->tm_year += 200;
        } else {
            tm->tm_year += 100;
        }
    } else {
        if(tm->tm_year < 70)
            tm->tm_year += 100;
    }


    /* Now check the status flags */
    if (date[M41T81_FLAGS] & M41T81_FLAGS_BLB)
    {
        batteryVoltLow = 1;
    }
    else
    {
        batteryVoltLow = 0;
    }

    if (  (date[M41T81_FLAGS] & M41T81_FLAGS_OFB)   /* Oscillator Failed Bit */
        ||(date[M41T81_SEC] & M41T81_SEC_ST)        /* Oscillator Stopped Bit */
       )
    {
        integrityFailed = 1;

        /* Oscillator is not running, reset it */
        dataWrite[0] = date[M41T81_SEC] | M41T81_SEC_ST;
        dataWrite[1] = dataWrite[0] & 0x7F;
        m41t81s_i2c_write(M41T81_SEC, dataWrite, 2);
        nap(1000);

        /* Tell the RTC to update it's registers. */
        if (date[M41T81_AL_HOUR] & M41T81_AL_HOUR_HTB)
        {
            dataWrite[0] = 0;  /* Clears M41T81_AL_HOUR_HTB */
            m41t81s_i2c_write(M41T81_AL_HOUR, dataWrite, 1);
        }

        /* Clear the Oscillator Fail flag.
         * In order to do that:  First write a data and time, then
         * wait 5s, and then clear the flag.  Failure to follow
         * these steps will result in the flag not getting cleared.
         * Note:  We'll use the current date and time stored in the RTC
         */
        date[M41T81_SEC] &= 0x7F;       /* Clear out the stop bit */
        m41t81s_i2c_write(M41T81_SSEC, date, M41T81_YEAR + 1);
        nap(5000);

        dataWrite[0] = 0;
        m41t81s_i2c_write(M41T81_FLAGS, dataWrite, 1);
    }

    return(0);
}

int
RTCFUNC(set,m41t81s)(struct tm *tm, int cent_reg)
{
    unsigned char   date[M41T81_YEAR+1];
    char   century;

    m41t81s_check_rtc_status();

    date[M41T81_SSEC]  = 0x00;
    date[M41T81_SEC]   = BIN2BCD(tm->tm_sec); /* implicitly clears stop bit */
    date[M41T81_MIN]   = BIN2BCD(tm->tm_min);
    date[M41T81_HOUR]  = BIN2BCD(tm->tm_hour) | M41T81_HOUR_CEB;
    date[M41T81_DAY]   = BIN2BCD( (tm->tm_wday + 1) );    /*RTC expects the day of the week to start with 1 */
    date[M41T81_DATE]  = BIN2BCD(tm->tm_mday);
    date[M41T81_MONTH] = BIN2BCD( (tm->tm_mon + 1) );     /*RTC expects the month to start with 1 */
    date[M41T81_YEAR]  = BIN2BCD( (tm->tm_year % 100) );

    century = tm->tm_year / 100 - 1;
    if (century != 0)
        date[M41T81_HOUR] |= M41T81_HOUR_CB;

    m41t81s_i2c_write(M41T81_SSEC, date, (M41T81_YEAR) + 1);
    integrityFailed = 0;    /* The time was just set so it has to be accurate. */

    return(0);
}

#if defined(__QNXNTO__) && defined(__USESRCVERSION)
#include <sys/srcversion.h>
__SRCVERSION("$URL: http://svn.ott.qnx.com/product/branches/6.6.0/trunk/utils/r/rtc/clk_m41t81s.c $ $Rev: 836809 $")
#endif
