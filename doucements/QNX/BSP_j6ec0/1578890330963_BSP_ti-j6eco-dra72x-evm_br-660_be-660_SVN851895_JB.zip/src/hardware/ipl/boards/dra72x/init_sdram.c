/*
 * $QNXLicenseC:
 * Copyright 2014, QNX Software Systems.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"). You
 * may not reproduce, modify or distribute this software except in
 * compliance with the License. You may obtain a copy of the License
 * at: http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OF ANY KIND, either express or implied.
 *
 * This file may contain contributions from others, either as
 * contributors under the License or as licensors under other terms.
 * Please review this entire file for other proprietary rights or license
 * notices, as well as the QNX Development Suite License Guide at
 * http://licensing.qnx.com/license-guide/ for other information.
 * $
 */

#include "board.h"

#define ARRAY_SIZE(x) (sizeof(x) / sizeof((x)[0]))

extern unsigned int chip_revision;

const struct emif_regs emif_1_regs_ddr3_666_mhz_1cs_dra_es1 = {
	.sdram_config_init			= 0x61862B32,
	.sdram_config				= 0x61862B32,
	.sdram_config2				= 0x08000000,
	.ref_ctrl					= 0x0000493E,
	.ref_ctrl_final				= 0x0000144A,
	.sdram_tim1					= 0xD113781C,
	.sdram_tim2					= 0x308F7FE3,
	.sdram_tim3					= 0x009F86A8,
	.read_idle_ctrl				= 0x00050000,
	.zq_config					= 0x0007190B,
	.temp_alert_config			= 0x00000000,
	.emif_ddr_phy_ctlr_1_init	= 0x0E24400D,
	.emif_ddr_phy_ctlr_1		= 0x0E24400D,
	.emif_ddr_ext_phy_ctrl_1	= 0x10040100,
	.emif_ddr_ext_phy_ctrl_2	= 0x00A400A4,
	.emif_ddr_ext_phy_ctrl_3	= 0x00A900A9,
	.emif_ddr_ext_phy_ctrl_4	= 0x00B000B0,
	.emif_ddr_ext_phy_ctrl_5	= 0x00B000B0,
	.emif_rd_wr_lvl_rmp_win		= 0x00000000,
	.emif_rd_wr_lvl_rmp_ctl		= 0x00000000,
	.emif_rd_wr_lvl_ctl			= 0x00000000,
	.emif_rd_wr_exec_thresh		= 0x00000305
};

const struct emif_regs emif_1_regs_ddr3_666_mhz_1cs_dra_es2 = {
	.sdram_config_init			= 0x61862BB2,
	.sdram_config				= 0x61862BB2,
	.sdram_config2				= 0x00000000,
	.ref_ctrl					= 0x0000514D,
	.ref_ctrl_final				= 0x0000144A,
	.sdram_tim1					= 0xD1137824,
	.sdram_tim2					= 0x30B37FE3,
	.sdram_tim3					= 0x409F8AD8,
	.read_idle_ctrl				= 0x00050000,
	.zq_config					= 0x5007190B,
	.temp_alert_config			= 0x00000000,
	.emif_ddr_phy_ctlr_1_init	= 0x0824400E,
	.emif_ddr_phy_ctlr_1		= 0x0E24400E,
	.emif_ddr_ext_phy_ctrl_1	= 0x04040100,
	.emif_ddr_ext_phy_ctrl_2	= 0x006B009F,
	.emif_ddr_ext_phy_ctrl_3	= 0x006B00A2,
	.emif_ddr_ext_phy_ctrl_4	= 0x006B00A8,
	.emif_ddr_ext_phy_ctrl_5	= 0x006B00A8,
	.emif_rd_wr_lvl_rmp_win		= 0x00000000,
	.emif_rd_wr_lvl_rmp_ctl		= 0x00000000,
	.emif_rd_wr_lvl_ctl			= 0x00000000,
	.emif_rd_wr_exec_thresh		= 0x00000305
};

const unsigned dra_ddr3_ext_phy_ctrl_const_base_es1_emif1_666MHz[] = {
	0x10040100,
	0x00A400A4,
	0x00A900A9,
	0x00B000B0,
	0x00B000B0,
	0x00A400A4,
	0x00390039,
	0x00320032,
	0x00320032,
	0x00320032,
	0x00440044,
	0x00550055,
	0x00550055,
	0x00550055,
	0x00550055,
	0x007F007F,
	0x004D004D,
	0x00430043,
	0x00560056,
	0x00540054,
	0x00600060,
	0x0,
	0x00600020,
	0x40010080,
	0x08102040,
	0x0,
	0x0,
	0x0,
	0x0,
	0x0

};

const unsigned dra_ddr3_ext_phy_ctrl_const_base_es2_emif1_666MHz[] = {
	0x04040100,
	0x006B009F,
	0x006B00A2,
	0x006B00A8,
	0x006B00A8,
	0x006B00B2,
	0x002F002F,
	0x002F002F,
	0x002F002F,
	0x002F002F,
	0x002F002F,
	0x00600073,
	0x00600071,
	0x0060007C,
	0x0060007E,
	0x00600084,
	0x00400053,
	0x00400051,
	0x0040005C,
	0x0040005E,
	0x00400064,
	0x00800080,
	0x00800080,
	0x40010080,
	0x08102040,
	0x005B008F,
	0x005B0092,
	0x005B0098,
	0x005B0098,
	0x005B00A2,
	0x00300043,
	0x00300041,
	0x0030004C,
	0x0030004E,
	0x00300054,
	0x00000077
};

/* EMIF_PWR_MGMT_CTRL register - Maximum delay before Low Power Modes */
#define EMIF_PWR_MGMT_CTRL_VAL			0xf2c0
#define EMIF_PWR_MGMT_CTRL_SHDW_VAL		0xf0c0

/* EMIF_L3_CONFIG register value */
#define EMIF_L3_CONFIG_VAL_SYS_10_MPU_3_LL_0	0x0A300000
#define EMIF_L3_CONFIG_VAL_SYS_10_MPU_5_LL_0	0x0A500000
#define PHY_RDDQS_RATIO_REGS			5
#define PHY_FIFO_WE_SLAVE_RATIO_REGS	5
#define PHY_REG_WR_DQ_SLAVE_RATIO_REGS	10


void emif_get_ext_phy_ctrl_const_regs(unsigned base, const unsigned **regs, unsigned *size)
{
	switch (chip_revision) {
		case DRA72x_ID_CODE_ES1_0:
			*regs = dra_ddr3_ext_phy_ctrl_const_base_es1_emif1_666MHz;
			*size = ARRAY_SIZE(dra_ddr3_ext_phy_ctrl_const_base_es1_emif1_666MHz);
			break;
		case DRA72x_ID_CODE_ES2_0:
		default:
			*regs = dra_ddr3_ext_phy_ctrl_const_base_es2_emif1_666MHz;
			*size = ARRAY_SIZE(dra_ddr3_ext_phy_ctrl_const_base_es2_emif1_666MHz);
			break;
	}
}

static void do_ext_phy_settings_dra7(unsigned base, const struct emif_regs *regs)
{
	const unsigned *ext_phy_ctrl_const_regs;
	unsigned i, hw_leveling, size;

	hw_leveling = regs->emif_rd_wr_lvl_rmp_ctl >> 31;

	emif_get_ext_phy_ctrl_const_regs(base, &ext_phy_ctrl_const_regs, &size);

	out32(base + EMIF_DDR_EXT_PHY_CTRL_X(0), ext_phy_ctrl_const_regs[0]);
	out32(base + EMIF_DDR_EXT_PHY_CTRL_X_SHDW(0), ext_phy_ctrl_const_regs[0]);

	if (!hw_leveling) {
		/* Copy the predefined PHY register values in case of sw leveling */
		for (i = 1; i < 25; i++) {
			out32(base + EMIF_DDR_EXT_PHY_CTRL_X(i), ext_phy_ctrl_const_regs[i]);
			out32(base + EMIF_DDR_EXT_PHY_CTRL_X_SHDW(i), ext_phy_ctrl_const_regs[i]);
		}
	} else {
		/* Write the init value for HW levling to occur */
		for (i = 21; i < 35; i++) {
			out32(base + EMIF_DDR_EXT_PHY_CTRL_X(i), ext_phy_ctrl_const_regs[i]);
			out32(base + EMIF_DDR_EXT_PHY_CTRL_X_SHDW(i), ext_phy_ctrl_const_regs[i]);
		}
	}
}

static void update_hwleveling_output(unsigned base, const struct emif_regs *regs)
{
	unsigned *emif_ext_phy_ctrl_reg, *emif_phy_status;
	unsigned reg, i, phy;

	phy = in32(base + EMIF_DDR_PHY_CTRL_1);

	/* Update PHY_REG_RDDQS_RATIO */
	if (!(phy & (1 << 27)))
		for (i = 0; i < PHY_RDDQS_RATIO_REGS; i++) {
			reg = in32(base + EMIF_DDR_EXT_PHY_STATUS(i + 6));
			out32(base + EMIF_DDR_EXT_PHY_CTRL_X(i + 6), reg);
			out32(base + EMIF_DDR_EXT_PHY_CTRL_X_SHDW(i + 6), reg);
		}

	/* Update PHY_REG_FIFO_WE_SLAVE_RATIO */
	if (!(phy & (1 << 26)))
		for (i = 0; i < PHY_FIFO_WE_SLAVE_RATIO_REGS; i++) {
			reg = in32(base + EMIF_DDR_EXT_PHY_STATUS(i + 11));
			out32(base + EMIF_DDR_EXT_PHY_CTRL_X(i + 1), reg);
			out32(base + EMIF_DDR_EXT_PHY_CTRL_X_SHDW(i + 1), reg);
		}

	/* Update PHY_REG_WR_DQ/DQS_SLAVE_RATIO */
	if (!(phy & (1 << 25)))
		for (i = 0; i < PHY_REG_WR_DQ_SLAVE_RATIO_REGS; i++) {
			reg = in32(base + EMIF_DDR_EXT_PHY_STATUS(i + 16));
			out32(base + EMIF_DDR_EXT_PHY_CTRL_X(i + 11), reg);
			out32(base + EMIF_DDR_EXT_PHY_CTRL_X_SHDW(i + 11), reg);
		}
	/* Disable Leveling */
 	out32(base + EMIF_DDR_PHY_CTRL_1, regs->emif_ddr_phy_ctlr_1);
 	out32(base + EMIF_DDR_PHY_CTRL_1_SHDW, regs->emif_ddr_phy_ctlr_1);
	out32(base + EMIF_RD_WR_LVL_RMP_CTL, 0x0);
}

static void dra7_ddr3_leveling(unsigned base, const struct emif_regs *regs)
{
	/* Clear Error Status */
	sr32(base + EMIF_DDR_EXT_PHY_CTRL_X(35), 8, 1, 1);
	sr32(base + EMIF_DDR_EXT_PHY_CTRL_X_SHDW(35), 8, 1, 1);

	/* Disable refreshed before leveling */
	sr32(base + EMIF_SDRAM_REF_CTRL, 31, 1, 1);

	/* Start Full leveling */
	out32(base + EMIF_RD_WR_LVL_CTL, 1 << 31);

	omap_usec_delay(300);

	/* check self clear bit whether full levelling is complete */
	if (in32(base + EMIF_RD_WR_LVL_CTL) & (1 << 31))
		ser_putstr("Levelling is not complete after 300us\n");

	/* Enable refreshes after leveling */
	sr32(base + EMIF_SDRAM_REF_CTRL, 31, 1, 0);

	/* Check for leveling timeout */
	if (in32(base + EMIF_STATUS) & (7 << 4)) {
		ser_putstr("Leveling timeout on EMIF\n");
		return;
	}

	/*
	 * Update slave ratios in EXT_PHY_CTRLx registers
	 * as per HW leveling output
	 */
	update_hwleveling_output(base, regs);
}

void emif_update_timings(unsigned base, const struct emif_regs *regs)
{
	out32(base + EMIF_SDRAM_REF_CTRL_SHDW, regs->ref_ctrl_final);

	out32(base + EMIF_SDRAM_TIM_1_SHDW, regs->sdram_tim1);
	out32(base + EMIF_SDRAM_TIM_2_SHDW, regs->sdram_tim2);
	out32(base + EMIF_SDRAM_TIM_3_SHDW, regs->sdram_tim3);

	out32(base + EMIF_PWR_MGMT_CTRL, EMIF_PWR_MGMT_CTRL_VAL);
	out32(base + EMIF_PWR_MGMT_CTRL_SHDW, EMIF_PWR_MGMT_CTRL_SHDW_VAL);

	out32(base + EMIF_DLL_CALIB_CTRL_SHDW, regs->read_idle_ctrl);
	out32(base + EMIF_ZQ_CONFIG, regs->zq_config);
	out32(base + EMIF_TEMP_ALERT_CONFIG, regs->temp_alert_config);
	out32(base + EMIF_DDR_PHY_CTRL_1_SHDW, regs->emif_ddr_phy_ctlr_1);

	out32(base + EMIF_OCP_CONFIG, EMIF_L3_CONFIG_VAL_SYS_10_MPU_5_LL_0);
}

/* Configure the EMIF. Table 15-112. EMIF Global Initialization */
void init_emif(unsigned base)
{
	int	i;
	unsigned	*ext_phy_ctrl_base;
	const struct emif_regs *regs;
	unsigned reg;
	unsigned *ext_phy_ctrl_const_regs;
	unsigned ext_phy_ctrl_size;

	if (base == DRA72X_EMIF1_BASE) {
		switch (chip_revision) {
			case DRA72x_ID_CODE_ES1_0:
				regs = &emif_1_regs_ddr3_666_mhz_1cs_dra_es1;
				break;
			case DRA72x_ID_CODE_ES2_0:
			default:
				regs = &emif_1_regs_ddr3_666_mhz_1cs_dra_es2;
				break;
		}
	}

    if (in32(DRA72X_PRM_BASE + PRM_RSTST) & PRM_RSTST_WARM_RESET_MASK) {
		/* On warm reset - Reset phy */
		reg = in32(base + EMIF_IODFT_TLGC);
		reg |= (1 << 10);
		out32 (base + EMIF_IODFT_TLGC, reg);
		out32(base + EMIF_PWR_MGMT_CTRL, 0x0);
	}

	do_ext_phy_settings_dra7(base, regs);

	out32(base + EMIF_SDRAM_REF_CTRL, regs->ref_ctrl | (1 << 31));

	/* Update ddr timing registers */
	out32(base + EMIF_SDRAM_TIM_1, regs->sdram_tim1);
	out32(base + EMIF_SDRAM_TIM_2, regs->sdram_tim2);
	out32(base + EMIF_SDRAM_TIM_3, regs->sdram_tim3);

	out32(base + EMIF_OCP_CONFIG, EMIF_L3_CONFIG_VAL_SYS_10_MPU_5_LL_0);
	out32(base + EMIF_DLL_CALIB_CTRL, regs->read_idle_ctrl);
	out32(base + EMIF_ZQ_CONFIG, regs->zq_config);
	out32(base + EMIF_TEMP_ALERT_CONFIG, regs->temp_alert_config);
	out32(base + EMIF_RD_WR_LVL_RMP_CTL, regs->emif_rd_wr_lvl_rmp_ctl);
	out32(base + EMIF_RD_WR_LVL_CTL, regs->emif_rd_wr_lvl_ctl);

	out32(base + EMIF_DDR_PHY_CTRL_1, regs->emif_ddr_phy_ctlr_1_init);
	out32(base + EMIF_RD_WR_EXEC_THRESH, regs->emif_rd_wr_exec_thresh);

	out32(base + EMIF_SDRAM_REF_CTRL, regs->ref_ctrl);

	out32(base + EMIF_SDRAM_CONFIG_2, regs->sdram_config2);
	out32(base + EMIF_SDRAM_CONFIG, regs->sdram_config_init);

	omap_usec_delay(1000);

	out32(base + EMIF_SDRAM_REF_CTRL, regs->ref_ctrl_final);

	if (regs->emif_rd_wr_lvl_rmp_ctl & (1 << 31)) {
		dra7_ddr3_leveling(base, regs);
	}

	/* Write to the shadow registers */
	emif_update_timings(base, regs);
}

/* Initialize the DDR SDRAM */
void init_sdram(void)
{
	out32(DRA72X_PRCM_BASE + CM_DLL_CTRL, 0);

	/* ddr init */
	init_dmm();
	init_emif(DRA72X_EMIF1_BASE);
}


#if defined(__QNXNTO__) && defined(__USESRCVERSION)
#include <sys/srcversion.h>
__SRCVERSION("$URL: http://svn.ott.qnx.com/product/branches/6.6.0/trunk/hardware/ipl/boards/dra72x/init_sdram.c $ $Rev: 810571 $")
#endif
