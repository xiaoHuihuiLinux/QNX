/*
 * $QNXLicenseC:
 * Copyright 2014, QNX Software Systems.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"). You
 * may not reproduce, modify or distribute this software except in
 * compliance with the License. You may obtain a copy of the License
 * at: http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OF ANY KIND, either express or implied.
 *
 * This file may contain contributions from others, either as
 * contributors under the License or as licensors under other terms.
 * Please review this entire file for other proprietary rights or license
 * notices, as well as the QNX Development Suite License Guide at
 * http://licensing.qnx.com/license-guide/ for other information.
 * $
 */

#include "board.h"

extern unsigned int chip_revision;

/* Get the device revision */
unsigned int get_omap_rev(void)
{
	return (in32(DRA72X_CTRL_WKUP_BASE + CTRL_WKUP_ID_CODE));
}

void print_omap_revision(void)
{
	switch (chip_revision) {
		case DRA72x_ID_CODE_ES1_0:
			ser_putstr("\nFound DRA72x ES1.0 SoC\n");
			break;
		case DRA72x_ID_CODE_ES2_0:
			ser_putstr("\nFound DRA72x ES2.0 SoC\n");
			break;
			default:
			log_putstr("\nUnknown DRA7xx SoC, assuming future rev. of DRA7xx: 0x\n");
			log_puthex(chip_revision);
			log_putstr("\n");
			break;
	}
}

void watchdog_init(void)
{
	out32(DRA72X_WDTIMER2_BASE + WDT_WSPR, DISABLE_SEQ_1);
	while (in32(DRA72X_WDTIMER2_BASE + WDT_WWPS))
		;
	out32(DRA72X_WDTIMER2_BASE + WDT_WSPR, DISABLE_SEQ_2);
	while (in32(DRA72X_WDTIMER2_BASE + WDT_WWPS))
		;
}

void watchdog_toggle(void)
{
	out32(DRA72X_WDTIMER2_BASE + WDT_WTGR, in32(DRA72X_WDTIMER2_BASE + WDT_WTGR) ^ 0xffffffff);
}

void io_settings(void)
{
	unsigned ctrl_base = DRA72X_CTRL_CORE_BASE;
	unsigned wkup_base = DRA72X_CTRL_WKUP_BASE;

	// PBIASLITE control
	out32(ctrl_base + CTRL_CORE_PBIAS, (1 << 27) | (1 << 26) | (1 << 21));

	// DDR3 pins IO settings
	// for DDR at 666MHz
	if (chip_revision == DRA72x_ID_CODE_ES1_0) {
		out32(ctrl_base + CTRL_DDR3CH1_0, 0x60606080);
		out32(ctrl_base + CTRL_DDRCH1_0, 0x40404040);
		out32(ctrl_base + CTRL_DDRCH1_1, 0x40404040);
		out32(ctrl_base + CTRL_DDRIO_0, 0x00094A40);
		out32(wkup_base + CTRL_WKUP_EMIF1_SDRAM_CONFIG_EXT, 0x0001C127);
	}
	else if (chip_revision == DRA72x_ID_CODE_ES2_0) {
		out32(ctrl_base + CTRL_DDR3CH1_0, 0x60606060);
		out32(ctrl_base + CTRL_DDRCH1_0, 0x40404040);
		out32(ctrl_base + CTRL_DDRCH1_1, 0x40404040);
		out32(ctrl_base + CTRL_DDRIO_0, 0x00094A40);
		out32(wkup_base + CTRL_WKUP_EMIF1_SDRAM_CONFIG_EXT, 0x0001C1A7);
	}
 }

#define _STR(x)				#x
#define MIN_GAS_VER(x)		_STR(x)
#define GAS_VERSION_221		22100

void init_l2actlr(void)
{
	unsigned val;
	unsigned monitor_id;
	register unsigned r12 asm ("r12");
	register unsigned r0 asm ("r0");

	/* Read Main ID Register (MIDR) */
	__asm__ __volatile__ ("mrc p15, 0, %0, c0, c0, 0" : "=r" (val));

	val = (val >> 4);
	val &= 0xf;

	if (val == 0xf) {
		__asm__ __volatile__ ("mrc p15, 1, %0, c15, c0, 0" : "=r" (val));

		/*
		 * TI Recommended: To prevent system instability and optimize performance
		 * L2ACTLR: Ensure to enable the following:
		 * 3: Disable clean/evict push to external
		 * 4: Disable WriteUnique and WriteLineUnique transactions from master
		 * 8: Disable DVM/CMO message broadcast
		 */
		val |= 0x118;

		/*
		 * ARM errata 798870: L2ACTLR[7]: Enable hazard detect timeout for A15.
		 * Set L2ACTLR[7] to reissue any memory transaction in the L2 that has been
		 * stalled for 1024 cycles to verify that its hazard condition still exists
		 */
		val |= (1 << 7);

		monitor_id = 0x104;

		/*Set L2 Cache Auxiliary control register - value to write in R0 */
		__asm__ __volatile__("mov %0, %1" : : "r"(r0), "r"(val));
		__asm__ __volatile__("mov %0, %1" : : "r"(r12), "r"(monitor_id));
		__asm__ __volatile__(
			"stmdb sp!, {r2-r12, lr}\n"
			"dsb\n"
			".ifdef .gasversion.\n"
			".if .gasversion. > " MIN_GAS_VER(GAS_VERSION_221) "\n"
			"	 .arch_extension sec\n"
			".endif\n"
			".endif\n"
			"smc #0\n"
			"ldmia sp!, {r2-r12, lr}\n" );
	}
}
 


#if defined(__QNXNTO__) && defined(__USESRCVERSION)
#include <sys/srcversion.h>
__SRCVERSION("$URL: http://svn.ott.qnx.com/product/branches/6.6.0/trunk/hardware/ipl/boards/dra72x/init_hw.c $ $Rev: 810483 $")
#endif
