/*
 * $QNXLicenseC:
 * Copyright 2008, QNX Software Systems. 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"). You 
 * may not reproduce, modify or distribute this software except in 
 * compliance with the License. You may obtain a copy of the License 
 * at: http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" basis, 
 * WITHOUT WARRANTIES OF ANY KIND, either express or implied.
 *
 * This file may contain contributions from others, either as 
 * contributors under the License or as licensors under other terms.  
 * Please review this entire file for other proprietary rights or license 
 * notices, as well as the QNX Development Suite License Guide at 
 * http://licensing.qnx.com/license-guide/ for other information.
 * $
 */




#include <pthread.h>
#include <sys/f3s_mtd.h>

/*
 * Description
 *
 * This is not a valid MTD callout. For internal use by other MTD callouts.
 */

int32_t amd_v2wordwrite(f3s_dbase_t * dbase,
                        f3s_access_t * access,
                        uint32_t flags,
                        uint32_t offset,
                        int32_t size,
                        uint8_t * buffer,
                        uintptr_t amd_cmd1,
                        uintptr_t amd_cmd2)
{
	volatile uint8_t *	memory;
	volatile uint8_t *	command;
	intunion_t			value;
	int32_t				left;
	int32_t				pad;
	int32_t				shift;

	amd_cmd1 *= flashcfg.bus_width;
	amd_cmd2 *= flashcfg.bus_width;

	/* set command pointer */
	command = access->service->page(&access->socket, F3S_POWER_ALL, offset & amd_command_mask, NULL);

	/* initialize number of bytes left to write */
	left = size;

	/* allign memory address */
	pad = offset & (flashcfg.bus_width - 1);

	offset -= pad;
	buffer -= pad;

	/* allign memory address */
	left += pad;

	/* set proper page on socket */
	memory = access->service->page(&access->socket, F3S_POWER_ALL, offset, &left);
	if (!memory) {
		fprintf(stderr, "(devf  t%d::%s:%d) page() returned NULL for offset 0x%x\n",
					pthread_self(), __func__, __LINE__, offset);
		return (-1);
	}

	/* set writeable size */
	size = left - pad;

	/* get value to write from buffer */
	memcpy((void *)&value, buffer, min(flashcfg.bus_width, left));

	/* check if padding is neccessary */
	if (pad) {
		/* calculate padding shift */
		shift = (flashcfg.bus_width - pad) << 3;
		pad_value(&value, memory, shift,1);
	}

	/* while there are bytes left to write loop */
	while (left > 0) {
		/* check if left is smaller than bus size */
		if (left < flashcfg.bus_width) {
			/* calculate padding shift */
			shift = left << 3;
			pad_value(&value, memory, shift,0);
		}

		/* check if no bits are cleared */
		if (value.w64 != F3S_A29F040_CLEAR) {
			/* issue unlock cycles */
			send_command(command + amd_cmd1, AMD_UNLOCK_CMD1);
			send_command(command + amd_cmd2, AMD_UNLOCK_CMD2);

			/* issue write command */
			send_command(command + amd_cmd1, AMD_PROGRAM);

			/* write value */
			write_value(memory, &value);

			/* DQ1 is "write-to-buffer abort", so never applies here */
			if (amd_poll(&value, command, 0) == -1) {
				fprintf(stderr,"(devf  t%d::%s:%d) over poll waiting for write completion\n",
							pthread_self(), __func__, __LINE__);
				errno = EIO;
				return (-1);
			}
		}

		/* decrement size left */
		left -= flashcfg.bus_width;

		/* check if there is still something to write */
		if (left > 0) {
			buffer += flashcfg.bus_width;
			memory += flashcfg.bus_width;
			memcpy((void *)&value, buffer, min(flashcfg.bus_width, left));
		}
	}

	/* check if verify is wanted */
	if (flags & F3S_VERIFY_WRITE) {
		/* check if everything was written properly */
		if (memcmp(buffer - size + left + flashcfg.bus_width,
		           (const void *)(((uint8_t *)memory) - size + left + flashcfg.bus_width), size))
		{
			fprintf(stderr, "(devf  t%d::%s:%d) program verify error\n"
						"between  0x%p and 0x%p\n"
						"memory = 0x%p, offset =  0x%x, left = %d, size = %d, bus_width = %d\n",
						pthread_self(), __func__, __LINE__,
						(((uint8_t *)memory) - size + left + flashcfg.bus_width),
						(((uint8_t *)memory) + left + flashcfg.bus_width),
						memory, offset, left, size, flashcfg.bus_width);
			errno = EIO;
			return (-1);
		}
	}

	/* everything went fine */
	return (size);
}

#if defined(__QNXNTO__) && defined(__USESRCVERSION)
#include <sys/srcversion.h>
__SRCVERSION("$URL: http://svn.ott.qnx.com/product/branches/6.6.0/trunk/hardware/flash/mtd-flash/amd/amd_v2wordwrite.c $ $Rev: 680332 $")
#endif
