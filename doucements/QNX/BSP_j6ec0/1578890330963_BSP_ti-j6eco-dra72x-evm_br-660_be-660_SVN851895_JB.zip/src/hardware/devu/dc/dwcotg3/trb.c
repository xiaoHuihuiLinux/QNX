
/*
 * $QNXLicenseC: 
 * Copyright 2011, QNX Software Systems.  
 *  
 * Licensed under the Apache License, Version 2.0 (the "License"). You  
 * may not reproduce, modify or distribute this software except in  
 * compliance with the License. You may obtain a copy of the License  
 * at: http://www.apache.org/licenses/LICENSE-2.0  
 *  
 * Unless required by applicable law or agreed to in writing, software  
 * distributed under the License is distributed on an "AS IS" basis,  
 * WITHOUT WARRANTIES OF ANY KIND, either express or implied. 
 * 
 * This file may contain contributions from others, either as  
 * contributors under the License or as licensors under other terms.   
 * Please review this entire file for other proprietary rights or license  
 * notices, as well as the QNX Development Suite License Guide at  
 * http://licensing.qnx.com/license-guide/ for other information. 
 * $
 */

/*
 * These funcstion are used to allocate and configure TRBs
 */
 
#include "dwcotg.h"


trb_ring_t *  trb_ring_alloc( dctrl_t * dc, int n_trb_in_ring ) {
	trb_ring_t      *trb_ring;
	int             err;
	
	trb_ring = calloc(1, sizeof( trb_ring_t ) );
	if ( trb_ring == NULL ) {
		dwcotg_slogf( dc, _SLOG_ERROR, "%s failed to calloc trb_ring struct",__func__);
		goto error;
	}
	trb_ring->dc = dc;
	trb_ring->n_trb_in_ring = n_trb_in_ring;
	trb_ring->n_trb_in_ring_mask = n_trb_in_ring - 1; // Assumption that n_trb_in_ring is always power of 2
	trb_ring->trb_mem_sz = ( n_trb_in_ring + 1 ) * sizeof( trb_t );

	/* map physical memory for the trb cluster, and get the physical address */
	trb_ring->trb_arr = 
		mmap64( 	NULL,
					trb_ring->trb_mem_sz, 
					PROT_READ | PROT_WRITE | PROT_NOCACHE,
					MAP_PRIVATE | MAP_ANON | MAP_PHYS,
					NOFD,
					0 									);
	if ( trb_ring->trb_arr == MAP_FAILED ) {
		dwcotg_slogf( dc, _SLOG_ERROR, "%s failed to mmap trb_ring",__func__);
		goto error2;
	}
	
	err = mem_offset64( 	trb_ring->trb_arr,
							NOFD,
							trb_ring->trb_mem_sz,
							&trb_ring->trb_base_paddr64,
							NULL					);
	if ( err != EOK ) {
		dwcotg_slogf( dc, _SLOG_ERROR, "%s failed to calc paddr64 for trb_ring",__func__ );
		goto error3;
	}

	dwcotg_slogf( dc, _SLOG_DEBUG1, "%s allocated cluster at paddr = 0x%llx",__func__, trb_ring->trb_base_paddr64 );	

	// link the last trb to the first to close the ring
	trb_ring->trb_arr[n_trb_in_ring].bufptr_low = trb_ring->trb_base_paddr64 & 0xffffffff;
	trb_ring->trb_arr[n_trb_in_ring].bufptr_high = trb_ring->trb_base_paddr64 >> 32;
	trb_ring->trb_arr[n_trb_in_ring].bufsz_sts = 0;
	trb_ring->trb_arr[n_trb_in_ring].control = TRB_CTL_HWO | TRBCTL_LINK_TRB;
	
	// create xlem companion array 
	trb_ring->xelem_arr = calloc( 1, ( n_trb_in_ring + 1 ) * sizeof(xelem_t*));
	if ( trb_ring->xelem_arr == NULL ) {
		dwcotg_slogf( dc, _SLOG_ERROR, "%s failed to calloc xelem arr",__func__ );
		goto error3;
	}
	return trb_ring;
error3:
	munmap( trb_ring->trb_arr,  trb_ring->trb_mem_sz );
error2:
	free( trb_ring );
error:
	return NULL;	
	
}

void trb_ring_free( dctrl_t * dc, trb_ring_t * trb_ring ) {
	munmap( trb_ring->trb_arr, trb_ring->trb_mem_sz );
	free( trb_ring->xelem_arr );
	free( trb_ring );
}


/* Control Packet: Setup Phase */
void trb_build_ctrl_setup( trb_ring_t * trb_ring, uint64_t setup_packet_paddr ) {
	volatile trb_t * trb = trb_ring->trb_arr;
	
	trb->bufptr_low = setup_packet_paddr & 0xffffffff;
	trb->bufptr_high = setup_packet_paddr >> 32;
	trb->bufsz_sts = SETUP_PACKET_SIZE;
	trb->control = TRB_CTL_HWO | TRB_CTL_LST | TRBCTL_CONTROL_SETUP | TRB_CTL_IOC;
}

/* Control Packet: Data Phase */
void trb_build_ctrl_data( trb_ring_t * trb_ring, uint64_t buf_paddr64, uint32_t size ) {
	volatile trb_t * trb = trb_ring->trb_arr;
	
	trb->bufptr_low = buf_paddr64 & 0xffffffff;
	trb->bufptr_high = buf_paddr64 >> 32;
	trb->bufsz_sts = size;
	trb->control = TRB_CTL_HWO | TRB_CTL_LST | TRBCTL_CONTROL_DATA | TRB_CTL_IOC;
}

/* Control Packet: Status Phase ( without data phase ) */
void trb_build_ctrl_status2( trb_ring_t * trb_ring ) {
	volatile trb_t * trb = trb_ring->trb_arr;

	trb->bufptr_low = 0;
	trb->bufptr_high = 0;
	trb->bufsz_sts = 0;
	trb->control = TRB_CTL_HWO | TRB_CTL_LST | TRBCTL_CONTROL_STATUS2 | TRB_CTL_IOC;
}

/* Control Packet: Status Phase ( with data phase ) */
void trb_build_ctrl_status3( trb_ring_t * trb_ring ) {
	volatile trb_t * trb = trb_ring->trb_arr;

	trb->bufsz_sts = 0;
	trb->bufptr_low = 0;
	trb->bufptr_high = 0;
	trb->control = TRB_CTL_HWO | TRB_CTL_LST | TRBCTL_CONTROL_STATUS3 | TRB_CTL_IOC;
}

/* This function assumes the normal trbs are used as part of a circular ring of trbs. So, this
 * function also manages the ring enqueue index
 */
int trb_build_normal( trb_ring_t * trb_ring, xelem_t * xelem ) {
	volatile trb_t * trb_arr = trb_ring->trb_arr;
	int enq_idx = trb_ring->enq_idx;
	int rc = EOK;

	// is enq_idx used? ... i.e. does the ring have room, or is it full
	if ( trb_ring->xelem_arr[enq_idx] == NULL ) {
		// populate trb
		trb_arr[enq_idx].bufptr_low = xelem->buffer_paddr64 & 0xffffffff;
		trb_arr[enq_idx].bufptr_high = xelem->buffer_paddr64 >> 32;
		trb_arr[enq_idx].bufsz_sts = xelem->length;
		trb_arr[enq_idx].control = TRB_CTL_HWO | TRBCTL_NORMAL | TRB_CTL_IOC | TRB_CTL_CSP;

		// associate xelem with trb 
		trb_ring->xelem_arr[enq_idx] = xelem;

		// bump the enqueue index while being mindful of the wrap conidtion
		trb_ring->enq_idx = ( enq_idx + 1) & trb_ring->n_trb_in_ring_mask;
	} else {
		dwcotg_slogf( trb_ring->dc, _SLOG_ERROR, "%s ring is FULL... no interrupts to reap transfers?, or is ring simply undersized enq_idx = %d deq_idx = %d "
				,__func__, trb_ring->enq_idx, trb_ring->deq_idx );
		rc = ENOMEM;
	}

	return rc;
}

/* This function assumes the normal trbs are used as part of a circular ring of trbs. So, this
 * function also manages the ring enqueue index
 */
int trb_build_isoch( trb_ring_t * trb_ring, xelem_t * xelem ) {
	volatile trb_t * trb_arr = trb_ring->trb_arr;
	int enq_idx = trb_ring->enq_idx;
	int rc = EOK;

	// is enq_idx used? ... i.e. does the ring have room, or is it full
	if ( trb_ring->xelem_arr[enq_idx] == NULL ) {
		// populate trb
		trb_arr[enq_idx].bufptr_low = xelem->buffer_paddr64 & 0xffffffff;
		trb_arr[enq_idx].bufptr_high = xelem->buffer_paddr64 >> 32;
		trb_arr[enq_idx].bufsz_sts = xelem->length;
		trb_arr[enq_idx].control = TRB_CTL_HWO | TRBCTL_ISOCH_FIRST | TRB_CTL_IOC | TRB_CTL_CSP;

		// associate xelem with trb 
		trb_ring->xelem_arr[enq_idx] = xelem;

		// bump the enqueue index while being mindful of the wrap conidtion
		trb_ring->enq_idx = ( enq_idx + 1) & trb_ring->n_trb_in_ring_mask;
	} else {
		dwcotg_slogf( trb_ring->dc, _SLOG_ERROR, "%s ring is FULL... no interrupts to reap transfers?, or is ring simply undersized enq_idx = %d deq_idx = %d "
				,__func__, trb_ring->enq_idx, trb_ring->deq_idx );
		rc = ENOMEM;
	}
	return rc;
}


/* This function assumes the normal trbs are used as part of a circular ring of trbs. So, this
 * function also manages the ring enqueue index
 */
int trb_build_streaming_isoch( trb_ring_t * trb_ring, xelem_t * xelem ) {
	volatile trb_t                 *trb_arr = trb_ring->trb_arr;
	int                            enq_idx = trb_ring->enq_idx;
	int                            rc = EOK;
	int                            i;
	int                            len;
	uint64_t                       paddr64 = xelem->buffer_paddr64;
	usbd_urb_isoch_stream_xfer_t   *isoch_multi = (usbd_urb_isoch_stream_xfer_t *) (xelem->urb->xdata_ptr );

	for( i=0; i < isoch_multi->nframes; i++) {

		if ( trb_ring->xelem_arr[enq_idx] != NULL ) {
			dwcotg_slogf( trb_ring->dc, _SLOG_ERROR, "%s ring is FULL... no interrupts to reap transfers?, or is ring simply undersized enq_idx = %d deq_idx = %d "
					,__func__, enq_idx, trb_ring->deq_idx );
			rc = ENOMEM;
			break;
		}

		len = isoch_multi->frame_list[i].frame_len;
		isoch_multi->frame_list[i].frame_status = 0; 

		// populate trb
		trb_arr[enq_idx].bufptr_low =paddr64 & 0xffffffff;
		trb_arr[enq_idx].bufptr_high = paddr64 >> 32;
		trb_arr[enq_idx].bufsz_sts = len;
		trb_arr[enq_idx].control = TRB_CTL_HWO | TRBCTL_ISOCH_FIRST | TRB_CTL_CSP |
		                           ( ( i == (isoch_multi->nframes-1) ) ? TRB_CTL_IOC : 0 );

		DWCOTG_SLOGF_DBG( trb_ring->dc, _SLOG_DEBUG1, "%s paddrlow = 0x%x paddrhi = 0x%x len = %d ctrl = 0x%x"
			,__func__,trb_arr[enq_idx].bufptr_low,trb_arr[enq_idx].bufptr_high,trb_arr[enq_idx].bufsz_sts ,trb_arr[enq_idx].control);

		// associate xelem with trb 
		trb_ring->xelem_arr[enq_idx] = xelem;

		// bump the enqueue index while being mindful of the wrap conidtion
		enq_idx = ( enq_idx + 1) & trb_ring->n_trb_in_ring_mask;

		// bump paddr for next isoch fragment
		paddr64 += len;
	}

	trb_ring->enq_idx = enq_idx;

	return rc;
}

#if defined(__QNXNTO__) && defined(__USESRCVERSION)
#include <sys/srcversion.h>
__SRCVERSION("$URL: http://svn.ott.qnx.com/product/branches/6.6.0/trunk/hardware/devu/dc/dwcotg3/trb.c $ $Rev: 820855 $")
#endif
