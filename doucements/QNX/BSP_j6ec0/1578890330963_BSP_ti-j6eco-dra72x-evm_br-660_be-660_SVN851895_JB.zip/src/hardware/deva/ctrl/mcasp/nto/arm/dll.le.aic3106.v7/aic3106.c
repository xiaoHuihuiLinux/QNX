/*
 * $QNXLicenseC:
 * Copyright 2015, QNX Software Systems.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"). You
 * may not reproduce, modify or distribute this software except in
 * compliance with the License. You may obtain a copy of the License
 * at: http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OF ANY KIND, either express or implied.
 *
 * This file may contain contributions from others, either as
 * contributors under the License or as licensors under other terms.
 * Please review this entire file for other proprietary rights or license
 * notices, as well as the QNX Development Suite License Guide at
 * http://licensing.qnx.com/license-guide/ for other information.
 * $
 */



/*
 *    aic3106.c
 *      The primary interface into the aic3106 codec.
 */

struct aic3106_context;
#define  MIXER_CONTEXT_T struct aic3106_context

#include "mcasp.h"
#include <hw/i2c.h>

enum
{
	AIC3106_PAGESELECTOR                = 0,
#define PAGE_SELECT                                 0
	AIC3106_SFT_RESET                   = 1,
#define SFT_RESET                                   (1<<7)
	AIC3106_CODEC_SAMPLE_RATE_SELEC     = 2,
	AIC3106_PLL_PROGRAM_REG_A           = 3,
#define REG_A_PLL_CTRL                              (1<<7)
#define REG_A_PLL_Q(i)                              (i<<3)
#define REG_A_PLL_P(i)                              (i<<0)
	AIC3106_PLL_PROGRAM_REG_B           = 4,
#define REG_B_PLL_J(i)                              (i<<2)
	AIC3106_PLL_PROGRAM_REG_C           = 5,
#define REG_C_PLL_D_MOST_BIT(i)                     ((i>>6) & 0xff) //0x36
	AIC3106_PLL_PROGRAM_REG_D           = 6,
#define REG_D_PLL_D_LEAST_BIT(i)                    ((i&0x3f)<<2)//0xb0
	AIC3106_CODEC_DATAPATH_SETUP        = 7,
#define RIGTH_DAC_DATAPATH_CTRL                     (1<<1)
#define LEFT_DAC_DATAPATH_CTRL                      (1<<3)
#define AGC_FS_REF_44100                            (1<<7)
	AIC3106_AUDIO_SER_DATA_INT_CTRL_A   = 8,
#define REG_A_BCLK_DIR_CTRL                         (1<<7)
#define REG_A_WCLK_DIR_CTRL                         (1<<6)
#define REG_A_SERIAL_DOUT_3STATE_CTRL               (1<<5)
	AIC3106_AUDIO_SER_DATA_INT_CTRL_B   = 9,
#define REG_B_BCLK_RATE_CTRL                        (1<<3)
#define REG_B_AUDIO_SERIAL_I2S_MODE                 (0<<6)
#define REG_B_AUDIO_SERIAL_DSP_MODE                 (1<<6)
	AIC3106_AUDIO_SER_DATA_INT_CTRL_C   = 10,
	AIC3106_AUDIO_CODEC_OVERFLOW_FLAG   = 11,
#define OVERFLOW_FLAG_PLL_R(i)                      (i<<0)
	AIC3106_AUDIO_CODEC_DFC             = 12, //DIGITAL FILTER CONTROL
	AIC3106_HEADSET_PRESS_DETECT_A      = 13,
	AIC3106_HEADSET_PRESS_DETECT_B      = 14,
	AIC3106_LEFT_ADC_PGA_GAIN_CTRL      = 15,
	AIC3106_RIGHT_ADC_PGA_GAIN_CTRL     = 16,
#define ADC_PGA_VOL_MASK                            (0x7f)
#define ADC_PGA_VOL_MUTE                            (1<<7)
	AIC3106_MIC3LR_TO_LEFT_ADC_CTRL     = 17,
#define MIC3R_INPUT_LEVEL_CTRL_LEFT_ADC_PGA_MIX     (0xf<<0)
#define MIC3L_INPUT_LEVEL_CTRL_LEFT_ADC_PGA_MIX     (0xf<<4)
	AIC3106_MIC3LR_TO_RIGHT_ADC_CTRL    = 18,
#define MIC3R_INPUT_LEVEL_CTRL_RIGHT_ADC_PGA_MIX    (0xf<<0)
#define MIC3L_INPUT_LEVEL_CTRL_RIGHT_ADC_PGA_MIX    (0xf<<4)
	AIC3106_LINE1L_TO_LEFT_ADC_CTRL     = 19,
#define LINE1L_LEFT_ADC_CHANNEL_POWER_CTRL          (1<<2)
#define LINE1L_INPUT_LEVEL_CTRL_LEFT_ADC_PGA_MIX    (0xf<<3)
	AIC3106_LINE2L_TO_LEFT_ADC_CTRL     = 20,
	AIC3106_LINE1R_TO_LEFT_ADC_CTRL     = 21,
	AIC3106_LINE1R_TO_RIGHT_ADC_CTRL    = 22,
#define LINE1R__RIGHT_ADC_CHANNEL_POWER_CTRL        (1<<2)
#define LINE1R__INPUT_LEVEL_CTRL_RIGHT_ADC_PGA_MIX  (0xf<<3)
	AIC3106_LINE2R_TO_RIGHT_ADC_CTRL    = 23,
	AIC3106_LINE1L_TO_RIGHT_ADC_CTRL    = 24,
	AIC3106_MICBIAS_CTRL                = 25,
#define MICBIAS_OFF                                 (0<<6)
#define MICBIAS_20                                  (1<<6)
#define MICBIAS_25                                  (2<<6)
#define MICBIAS_AVDD                                (3<<6)
	AIC3106_LEFT_AGC_CTRL_A             = 26,
	AIC3106_LEFT_AGC_CTRL_B             = 27,
	AIC3106_LEFT_AGC_CTRL_C             = 28,
	AIC3106_RIGHT_AGC_CTRL_A            = 29,
	AIC3106_RIGHT_AGC_CTRL_B            = 30,
	AIC3106_RIGHT_AGC_CTRL_C            = 31,
	AIC3106_LEFT_AGC_GAIN               = 32,
	AIC3106_RIGHT_AGC_GAIN              = 33,
	AIC3106_LEFT_AGC_NOISE_GATE_DEBNC   = 34,
	AIC3106_RIGHT_AGC_NOISE_GATE_DEBNC  = 35,
	AIC3106_ADC_FLAG                    = 36,
	AIC3106_DAC_POWER_DRIVER_CTRL       = 37,
#define LEFT_DAC_POWER_CTRL                         (1<<7)
#define RIGHT_DAC_POWER_CTRL                        (1<<6)
	AIC3106_HPOWER_DRIVER_CTRL          = 38,
	AIC3106_RESERVED_REG_1              = 39,
	AIC3106_HIGH_POWER_STAGE_CTRL       = 40,
	AIC3106_DAC_OUTPUT_SWITCH_CTRL      = 41,
#define RIGHT_DAC_OUT_SWITCHING_CTRL                (1<<4)
#define LEFT_DAC_OUT_SWITCHING_CTRL                 (1<<6)
	AIC3106_OUTPUT_DRIVER_POP_REDUCTION = 42,
#define POWER_ON_TIME_200MS                         (0x7<<4)
#define POWER_ON_TIME_4S                            (0xb<<4)
#define RAMP_UP_STEP_TIME_2MS                       (0x2<<2)
	AIC3106_LEFT_DAC_DIG_VOL_CTRL       = 43,
	AIC3106_RIGHT_DAC_DIG_VOL_CTRL      = 44,
#define DAC_DIG_VOL_MASK                            (0x7f)
#define DAC_DIG_VOL_MUTE                            (1<<7)
	AIC3106_LINE2L_TO_HPLOUT_VOL_CTRL   = 45,
	AIC3106_PGA_L_TO_HPLOUT_VOL_CTRL    = 46,
	AIC3106_DAC_L1_TO_HPLOUT_VOL_CTRL   = 47,
#define DAC_L1_ROUTED_TO_HPLOUT                     (1<<7)
	AIC3106_LINE2R_TO_HPLOUT_VOL_CTRL   = 48,
	AIC3106_PGA_R_TO_HPLOUT_VOL_CTRL    = 49,
	AIC3106_DAC_R1_TO_HPLOUT_VOL_CTRL   = 50,
	AIC3106_HPLOUT_OUTPUT_LVL_CTRL      = 51,
#define HPLOUT_POWER_CTRL                           (1<<0)
#define HPLOUT_MUTE                                 (1<<3)
	AIC3106_LINE2L_TO_HPLCOM_VOL_CTRL   = 52,
	AIC3106_PGA_L_TO_HPLCOM_VOL_CTRL    = 53,
	AIC3106_DAC_L1_TO_HPLCOM_VOL_CTRL   = 54,
	AIC3106_LINE2R_TO_HPLCOM_VOL_CTRL   = 55,
	AIC3106_PGA_R_TO_HPLCOM_VOL_CTRL    = 56,
	AIC3106_DAC_R1_TO_HPLCOM_VOL_CTRL   = 57,
	AIC3106_HPLCOM_OUTPUT_LVL_CTRL      = 58,
	AIC3106_LINE2L_TO_HPROUT_VOL_CTRL   = 59,
	AIC3106_PGA_L_TO_HPROUT_VOL_CTRL    = 60,
	AIC3106_DAC_L1_TO_HPROUT_VOL_CTRL   = 61,
	AIC3106_LINE2R_TO_HPROUT_VOL_CTRL   = 62,
	AIC3106_PGA_R_TO_HPROUT_VOL_CTRL    = 63,
	AIC3106_DAC_R1_TO_HPROUT_VOL_CTRL   = 64,
#define DAC_R1_ROUTED_TO_HPROUT                     (1<<7)
	AIC3106_HPROUT_OUTPUT_LVL_CTRL      = 65,
#define HPROUT_POWER_CTRL                           (1<<0)
#define HPROUT_MUTE                                 (1<<3)
	AIC3106_LINE2L_TO_HPRCOM_VOL_CTRL   = 66,
	AIC3106_PGA_L_HPRCOM_VOL_CTRL       = 67,
	AIC3106_DAC_L1_TO_HPRCOM_VOL_CTRL   = 68,
	AIC3106_LINE2R_TO_HPRCOM_VOL_CTRL   = 69,
	AIC3106_PGA_R_TO_HPRCOM_VOL_CTRL    = 70,
	AIC3106_DAC_R1_TO_HPRCOM_VOL_CTRL   = 71,
	AIC3106_HPRCOM_OUTPUT_LVL_CTRL      = 72,
	AIC3106_LINE2L_TO_MONOLOP_VOL_CTRL  = 73,
	AIC3106_PGA_L_MONOLOP_VOL_CTRL      = 74,
	AIC3106_DAC_L1_TO_MONOLOP_VOL_CTRL  = 75,
	AIC3106_LINE2R_TO_MONOLOP_VOL_CTRL  = 76,
	AIC3106_PGA_R_TO_MONOLOP_VOL_CTRL   = 77,
	AIC3106_DAC_R1_TO_MONOLOP_VOL_CTRL  = 78,
	AIC3106_MONOLOP_OUTPUT_LVL_CTRL     = 79,
	AIC3106_LINE2L_TO_LEFTLOP_VOL_CTRL  = 80,
	AIC3106_PGA_L_TO_LEFTLOP_VOL_CTRL   = 81,
	AIC3106_DAC_L1_TO_LEFTLOP_VOL_CTRL  = 82,
#define DAC_L1_ROUTED_TO_LEFTLOP                    (1<<7)
	AIC3106_LINE2R_TO_LEFTLOP_VOL_CTRL  = 83,
	AIC3106_PGA_R_TO_LEFTLOP_VOL_CTRL   = 84,
	AIC3106_DAC_R1_TO_LEFTLOP_VOL_CTRL  = 85,
	AIC3106_LEFTLOP_OUTPUT_LVL_CTRL     = 86,
#define LEFTLOP_LEFT_LOP_M_POWER_STATUS             (1<<0)
#define LEFTLOP_LEFT_LOP_M_MUTE                     (1<<3)
	AIC3106_LINE2L_TO_RIGHTLOP_VOL_CTRL = 87,
	AIC3106_PGA_L_TO_RIGHTLOP_VOL_CTRL  = 88,
	AIC3106_DAC_L1_TO_RIGHTLOP_VOL_CTRL = 89,
	AIC3106_LINE2R_TO_RIGHTLOP_VOL_CTRL = 90,
	AIC3106_PGA_R_TO_RIGHTLOP_VOL_CTRL  = 91,
	AIC3106_DAC_R1_TO_RIGHTLOP_VOL_CTRL = 92,
#define DAC_R1_ROUTED_TO_RIGHTLOP                   (1<<7)
	AIC3106_RIGHTLOP_OUTPUT_LVL_CTRL    = 93,
#define RIGHTLOP_RIGHT_LOP_M_POWER_STATUS           (1<<0)
#define RIGHTLOP_RIGHT_LOP_M_MUTE                   (1<<3)
	AIC3106_MODULE_PWR_STAT             = 94,
	AIC3106_OUTPUT_DRIVER_SHORT_CRCT_DETEC_STAT = 95,
	AIC3106_STICKY_INTERRUPT_FLAGS      = 96,
	AIC3106_REALTIME_INTERRUPT_FLAGS    = 97,
	AIC3106_GPIO1_CTRL                  = 98,
	AIC3106_GPIO2_CTRL                  = 99,
	AIC3106_ADDITIONAL_GPIO_CTRL_A      = 100,
	AIC3106_ADDITIONAL_GPIO_CTRL_B      = 101,
#define CODEC_CLKIN_SOURCE_PLLDIV                   (0<<0)
#define CODEC_CLKIN_SOURCE_CLKDIV                   (1<<0)
	AIC3106_CLK_GENERATION_CTRL         = 102,
#define CLKDIV_IN_USE_BCLK                          (2<<6)
#define PLLCLK_USE_BCLK                             (2<<4)
};

typedef struct aic3106_context
{
	ado_mixer_t  *mixer;
	HW_CONTEXT_T *hwc;
	int          fd;
	int          num_of_codecs;
	int          i2c_addr[3];

	int          sel_mcasp;
#define SEL_MCASP2 0
#define SEL_MCASP5 1

	int          left_adc_pga_gain_ctrl[3];
	int          right_adc_pga_gain_ctrl[3];

	int          left_dac_vol_ctrl[3];
	int          right_dac_vol_ctrl[3];

	uint8_t      output_routing; /* for McASP2 (hp or lineout) */

	uint8_t      input_mux; /* 0: mic1, 1: mic2, 2: aux*/
#define MIC1_IN_INPUT       0
#define AUX_IN_INPUT        1
#define MIC2_IN_INPUT       2

#define SWITCH_LINEOUT      0
#define SWITCH_HPOUT        1
#define DAC_TO_LR1          (0x00)
#define DAC_TO_LR3          (0x50)
#define SWITCH_HP_LINE_MASK (0xf0)

	ado_mixer_delement_t *mic1_in;
	ado_mixer_delement_t *aux_in;
}
aic3106_context_t;

/*
 If MCLK is an even multiple of sampling frequency, we do not need
 to turn on internal codec PLL, and we can use 'Q' to obtain desired
 frequency:
      fs = (MCLK) / (128 * Q)

 If MCLK is not an even multiple of sampling frequency, we need to
 use internal PLL and obtain desired frequency using P,R,K=J.D using
 the following formula:

      fs = (MCLK * K * R) / (2048 * P)
      where K = J.D (J is the integer portion of K, D is the fraction)

 For example: Given MCLK=24.576MHz, Fs=44.1KHz, and assuming R=1, we have:

 P = 2 [10MHz <= (MCLK/P) <= 20MHz]

 K = (44100 * 2048 * 2)/(24576000) = 7.35
 Therefore, J = 7 [4 <= J <= 55]
      D = 3500

 Finally, the above calculation meet the final requirement:
 80MHz <= (MCLK * K * R / P) <= 110MHz

 */

#define NUM_CLOCK_ENTRIES 3
static uint32_t codec_pll_dividers[NUM_CLOCK_ENTRIES][6] = {
                             /* MCLK    Q  P  R  J  D */
	/* mclk = 11.2896 MHz */   {11289600, 0, 1, 1, 8, 0},
	/* mclk = 20.0214 MHz */   {20021400, 0, 1, 1, 4, 5110},
	/* mclk = 45.1584 MHz */   {45158400, 8, 0, 0, 0, 0},
};

#define MCLK_INDEX  0
#define PLL_Q_INDEX 1
#define PLL_P_INDEX 2
#define PLL_R_INDEX 3
#define PLL_J_INDEX 4
#define PLL_D_INDEX 5

static int32_t pcm_devices[1] = {
	0
};

static snd_mixer_voice_t mono_voices[1] = {
	{SND_MIXER_VOICE_LEFT, 0}
};

static snd_mixer_voice_t stereo_voices[2] = {
	{SND_MIXER_VOICE_LEFT, 0},
	{SND_MIXER_VOICE_RIGHT, 0}
};

static snd_mixer_voice_t quad_voices[4] = {
	{SND_MIXER_VOICE_LEFT, 0},
	{SND_MIXER_VOICE_RIGHT, 0},
	{SND_MIXER_VOICE_REAR_LEFT, 0},
	{SND_MIXER_VOICE_REAR_RIGHT, 0}
};

static snd_mixer_voice_t five_one_voices[6] = {
	{SND_MIXER_VOICE_LEFT, 0},
	{SND_MIXER_VOICE_RIGHT, 0},
	{SND_MIXER_VOICE_CENTER, 0},
	{SND_MIXER_VOICE_REAR_LEFT, 0},
	{SND_MIXER_VOICE_REAR_RIGHT, 0},
	{SND_MIXER_VOICE_WOOFER, 0}
};

static snd_mixer_voice_t seven_one_voices[8] = {
	{SND_MIXER_VOICE_LEFT, 0},
	{SND_MIXER_VOICE_RIGHT, 0},
	{SND_MIXER_VOICE_CENTER, 0},
	{SND_MIXER_VOICE_REAR_LEFT, 0},
	{SND_MIXER_VOICE_REAR_RIGHT, 0},
	{SND_MIXER_VOICE_WOOFER, 0},
	{SND_MIXER_VOICE_SURR_LEFT, 0},
	{SND_MIXER_VOICE_SURR_RIGHT, 0}
};

static struct snd_mixer_element_volume1_range output_range[8] = {
	{0, 127, -6350, 0},
	{0, 127, -6350, 0},
	{0, 127, -6350, 0},
	{0, 127, -6350, 0},
	{0, 127, -6350, 0},
	{0, 127, -6350, 0},
	{0, 127, -6350, 0},
	{0, 127, -6350, 0}
};

static struct snd_mixer_element_volume1_range input_range[8] = {
	{0, 119, 0, 5950},
	{0, 119, 0, 5950},
	{0, 119, 0, 5950},
	{0, 119, 0, 5950},
	{0, 119, 0, 5950},
	{0, 119, 0, 5950},
	{0, 119, 0, 5950},
	{0, 119, 0, 5950}
};

static uint8_t aic3106_rd(MIXER_CONTEXT_T * aic3106, uint8_t regaddr, uint8_t slave_addr)
{
	struct send_recv
	{
		i2c_sendrecv_t hdr;
		uint8_t buf[2];
	} aic3106_rd_data;

	/* Read the Registers Current Value */
	aic3106_rd_data.buf[0] = regaddr;
	aic3106_rd_data.hdr.send_len = 1;
	aic3106_rd_data.hdr.recv_len = 1;

	aic3106_rd_data.hdr.slave.addr = slave_addr;
	aic3106_rd_data.hdr.slave.fmt = I2C_ADDRFMT_7BIT;
	aic3106_rd_data.hdr.stop = 1;

	if (devctl(aic3106->fd, DCMD_I2C_SENDRECV, &aic3106_rd_data, sizeof (aic3106_rd_data), NULL))
	{
		ado_error("Failed to read to codec: %s\n", strerror(errno));
	}

	ado_debug(DB_LVL_MIXER, "AIC3106 Codec read reg=%x data=%x (%d) ,slave_addr = %x", regaddr, aic3106_rd_data.buf[0],
			  aic3106_rd_data.buf[0], slave_addr);
	return aic3106_rd_data.buf[0];
}

static int8_t aic3106_wr(MIXER_CONTEXT_T * aic3106, uint8_t regaddr, uint8_t data, uint8_t slave_addr)
{
	struct send_recv
	{
		i2c_sendrecv_t hdr;
		uint8_t buf[2];
	} aic3106_rw_data;

	int8_t wr_error = 0;

	/*Read the Registers Current Value */
	aic3106_rw_data.buf[0] = regaddr;
	aic3106_rw_data.buf[1] = data;
	aic3106_rw_data.hdr.send_len = 2;
	aic3106_rw_data.hdr.recv_len = 1;

	aic3106_rw_data.hdr.slave.addr = slave_addr;
	aic3106_rw_data.hdr.slave.fmt = I2C_ADDRFMT_7BIT;
	aic3106_rw_data.hdr.stop = 1;

	if (devctl(aic3106->fd, DCMD_I2C_SENDRECV, &aic3106_rw_data, sizeof (aic3106_rw_data), NULL))
	{
		wr_error = 1;
		ado_error("Failed to write to codec: %s\n", strerror(errno));
	}

	ado_debug(DB_LVL_MIXER, "AIC3106 Codec write reg=%x data=%x (%d), slave_addr = %x", regaddr, data, data, slave_addr);
	/* Wait and then do dumby reads to ensure the codec write is applied */
	delay(5);
	aic3106_rd(aic3106, regaddr, slave_addr);
	aic3106_rd(aic3106, regaddr, slave_addr);
	return wr_error;
}

static int32_t
aic3106_output_vol_control(MIXER_CONTEXT_T * aic3106, ado_mixer_delement_t * element, uint8_t set,
						   uint32_t * vol, void *instance_data)
{
	int i, chn_idx;
	int32_t altered = 0;

	if(set)
	{
		for(i = 0, chn_idx = 0; i < aic3106->num_of_codecs; i++, chn_idx+=2)
		{
			/* If 4 channel configuration, skip over Front-Center channel placement */
			if (aic3106->hwc->play_strm.voices == 4 && chn_idx == SND_MIXER_CHN_FRONT_CENTER)
				chn_idx++;

			if (vol[chn_idx] != (127 - (aic3106->left_dac_vol_ctrl[i] & DAC_DIG_VOL_MASK)))
			{
				altered = 1;
				aic3106->left_dac_vol_ctrl[i] &= DAC_DIG_VOL_MUTE;
				aic3106->left_dac_vol_ctrl[i] |= 127 - (vol[chn_idx] & DAC_DIG_VOL_MASK);
				aic3106_wr(aic3106, AIC3106_LEFT_DAC_DIG_VOL_CTRL, aic3106->left_dac_vol_ctrl[i], aic3106->i2c_addr[i]);
			}

			if (vol[chn_idx+1] != (127 - (aic3106->right_dac_vol_ctrl[i] & DAC_DIG_VOL_MASK)))
			{
				altered = 1;
				aic3106->right_dac_vol_ctrl[i] &= DAC_DIG_VOL_MUTE;
				aic3106->right_dac_vol_ctrl[i] |= 127 - (vol[chn_idx+1] & DAC_DIG_VOL_MASK);
				aic3106_wr(aic3106, AIC3106_RIGHT_DAC_DIG_VOL_CTRL, aic3106->right_dac_vol_ctrl[i], aic3106->i2c_addr[i]);
			}
		}
	}
	else
	{
		for(i = 0, chn_idx = 0; i < aic3106->num_of_codecs; i++, chn_idx+=2)
		{
			/* If 4 channel configuration, skip over Front-Center channel placement */
			if (aic3106->hwc->play_strm.voices == 4 && chn_idx == SND_MIXER_CHN_FRONT_CENTER)
				chn_idx++;

			vol[chn_idx] = 127 - (aic3106->left_dac_vol_ctrl[i] & DAC_DIG_VOL_MASK);
			vol[chn_idx+1] = 127 - (aic3106->right_dac_vol_ctrl[i] & DAC_DIG_VOL_MASK);
		}
	}
	return (altered);
}

static int32_t
aic3106_output_mute_control(MIXER_CONTEXT_T * aic3106, ado_mixer_delement_t * element, uint8_t set,
							uint32_t * val, void *instance_data)
{
	int i, chn_idx;
	uint32_t mute_map = 0;
	int32_t altered = 0;

	for (i = 0, chn_idx = 0; i < aic3106->num_of_codecs; i++, chn_idx+=2)
	{
		/* If 4 channel configuration, skip over Front-Center channel placement */
		if (aic3106->hwc->play_strm.voices == 4 && chn_idx == SND_MIXER_CHN_FRONT_CENTER)
			chn_idx++;

		mute_map |= (aic3106->left_dac_vol_ctrl[i] & DAC_DIG_VOL_MUTE) >> (7-chn_idx);
		mute_map |= (aic3106->right_dac_vol_ctrl[i] & DAC_DIG_VOL_MUTE) >> (7-(chn_idx+1));
	}

	if (set)
	{
		altered = (mute_map != val[0]);
		if (altered)
		{
			for (i = 0, chn_idx = 0; i < aic3106->num_of_codecs; i++, chn_idx+=2)
			{
				/* If 4 channel configuration, skip over Front-Center channel placement */
				if (aic3106->hwc->play_strm.voices == 4 && chn_idx == SND_MIXER_CHN_FRONT_CENTER)
					chn_idx++;

				aic3106->left_dac_vol_ctrl[i] &= DAC_DIG_VOL_MASK;
				if (val[0] & (1<<chn_idx))
					aic3106->left_dac_vol_ctrl[i] |= DAC_DIG_VOL_MUTE;

				aic3106->right_dac_vol_ctrl[i] &= DAC_DIG_VOL_MASK;
				if (val[0] & (1<<(chn_idx+1)))
					aic3106->right_dac_vol_ctrl[i] |= DAC_DIG_VOL_MUTE;

				aic3106_wr(aic3106, AIC3106_LEFT_DAC_DIG_VOL_CTRL, aic3106->left_dac_vol_ctrl[i], aic3106->i2c_addr[i]);
				aic3106_wr(aic3106, AIC3106_RIGHT_DAC_DIG_VOL_CTRL, aic3106->right_dac_vol_ctrl[i], aic3106->i2c_addr[i]);
			}
		}
	}
	else
	{
		val[0] = mute_map;
	}

	return (altered);
}

static int32_t
aic3106_hp_get(MIXER_CONTEXT_T * aic3106, ado_dswitch_t * dswitch, snd_switch_t * cswitch, void *instance_data)
{
	cswitch->type = SND_SW_TYPE_BOOLEAN;
	if(aic3106_rd(aic3106, AIC3106_DAC_L1_TO_LEFTLOP_VOL_CTRL, aic3106->i2c_addr[0]) & DAC_L1_ROUTED_TO_LEFTLOP)
		cswitch->value.enable = SWITCH_LINEOUT;
	else
		cswitch->value.enable = SWITCH_HPOUT;

	return (0);
}

static int32_t
aic3106_hp_set(MIXER_CONTEXT_T * aic3106, ado_dswitch_t * dswitch, snd_switch_t * cswitch, void *instance_data)
{
	int32_t altered = 0;

	if((cswitch->value.enable == SWITCH_LINEOUT) && (aic3106->output_routing != SWITCH_LINEOUT))
	{
		/* Disconnect DAC_L1/DAC_R1 from HPROUT */
		aic3106_wr(aic3106, AIC3106_DAC_L1_TO_HPLOUT_VOL_CTRL, 0x0, aic3106->i2c_addr[0]);
		aic3106_wr(aic3106, AIC3106_DAC_R1_TO_HPROUT_VOL_CTRL, 0x0, aic3106->i2c_addr[0]);

		/* Connect DAC_L1/DAC_R1 to LOP (Line output) */
		aic3106_wr(aic3106, AIC3106_DAC_L1_TO_LEFTLOP_VOL_CTRL, DAC_L1_ROUTED_TO_LEFTLOP, aic3106->i2c_addr[0]);
		aic3106_wr(aic3106, AIC3106_DAC_R1_TO_RIGHTLOP_VOL_CTRL, DAC_R1_ROUTED_TO_RIGHTLOP, aic3106->i2c_addr[0]);

		aic3106->output_routing = SWITCH_LINEOUT;
		altered = 1;
	}
	else if ((cswitch->value.enable == SWITCH_HPOUT) && (aic3106->output_routing != SWITCH_HPOUT))
	{
		/* Disconnect DAC_L1/DAC_R1 from LOP (Line output) */
		aic3106_wr(aic3106, AIC3106_DAC_L1_TO_LEFTLOP_VOL_CTRL, 0x0, aic3106->i2c_addr[0]);
		aic3106_wr(aic3106, AIC3106_DAC_R1_TO_RIGHTLOP_VOL_CTRL, 0x0, aic3106->i2c_addr[0]);

		/* Connect DAC_L1/DAC_R1 to HPROUT */
		aic3106_wr(aic3106, AIC3106_DAC_L1_TO_HPLOUT_VOL_CTRL, DAC_L1_ROUTED_TO_HPLOUT, aic3106->i2c_addr[0]);
		aic3106_wr(aic3106, AIC3106_DAC_R1_TO_HPROUT_VOL_CTRL, DAC_R1_ROUTED_TO_HPROUT, aic3106->i2c_addr[0]);

		aic3106->output_routing = SWITCH_HPOUT;
		altered = 1;
	}

	return altered;
}
static int32_t
aic3106_mux_control(MIXER_CONTEXT_T * aic3106, ado_mixer_delement_t * element, uint8_t set,ado_mixer_delement_t ** inelements, void *instance_data)
{
	int32_t altered = 0;
	uint32_t tmp;

	if (set)
	{
		if(aic3106->hwc->cap_aif.active)
			return (EBUSY);						 /* Cannot switch while capture is active */

		if(inelements[0] == aic3106->mic1_in)
			tmp = MIC1_IN_INPUT;
		else
			tmp = AUX_IN_INPUT;
		altered = aic3106->input_mux != tmp;

		aic3106->input_mux = tmp;

		if(MIC1_IN_INPUT == aic3106->input_mux) /* Mic */
		{
			/* disconnect Line1L and Line1R from Left and Right ADC */
			aic3106_wr(aic3106, AIC3106_LINE1L_TO_LEFT_ADC_CTRL,(LINE1L_LEFT_ADC_CHANNEL_POWER_CTRL | LINE1L_INPUT_LEVEL_CTRL_LEFT_ADC_PGA_MIX) , aic3106->i2c_addr[0]);
			aic3106_wr(aic3106, AIC3106_LINE1R_TO_RIGHT_ADC_CTRL, (LINE1R__RIGHT_ADC_CHANNEL_POWER_CTRL | LINE1R__INPUT_LEVEL_CTRL_RIGHT_ADC_PGA_MIX), aic3106->i2c_addr[0]);

			/* connect MIC3L to Left ADC and MIC3R to right ADC */
			aic3106_wr(aic3106, AIC3106_MIC3LR_TO_LEFT_ADC_CTRL, MIC3R_INPUT_LEVEL_CTRL_LEFT_ADC_PGA_MIX, aic3106->i2c_addr[0]);
			aic3106_wr(aic3106, AIC3106_MIC3LR_TO_RIGHT_ADC_CTRL, MIC3L_INPUT_LEVEL_CTRL_RIGHT_ADC_PGA_MIX, aic3106->i2c_addr[0]);
		}
		else /* Aux input */
		{
			/* disconnect MIC3L to Left ADC and MIC3R to right ADC */
			aic3106_wr(aic3106, AIC3106_MIC3LR_TO_LEFT_ADC_CTRL,(MIC3R_INPUT_LEVEL_CTRL_LEFT_ADC_PGA_MIX | MIC3L_INPUT_LEVEL_CTRL_LEFT_ADC_PGA_MIX), aic3106->i2c_addr[0]);
			aic3106_wr(aic3106, AIC3106_MIC3LR_TO_RIGHT_ADC_CTRL,(MIC3R_INPUT_LEVEL_CTRL_RIGHT_ADC_PGA_MIX | MIC3L_INPUT_LEVEL_CTRL_RIGHT_ADC_PGA_MIX), aic3106->i2c_addr[0]);

			/* connect Line1L and Line1R from Left and Right ADC */
			aic3106_wr(aic3106, AIC3106_LINE1L_TO_LEFT_ADC_CTRL, LINE1L_LEFT_ADC_CHANNEL_POWER_CTRL, aic3106->i2c_addr[0]);
			aic3106_wr(aic3106, AIC3106_LINE1R_TO_RIGHT_ADC_CTRL, LINE1R__RIGHT_ADC_CHANNEL_POWER_CTRL, aic3106->i2c_addr[0]);
		}
	}
	else
	{
		if(MIC1_IN_INPUT == aic3106->input_mux)
			inelements[0] = inelements[1] = aic3106->mic1_in;
		else
			inelements[0] = inelements[1] = aic3106->aux_in;
	}
	return (altered);
}


static int32_t
aic3106_input_vol_control(MIXER_CONTEXT_T * aic3106, ado_mixer_delement_t * element, uint8_t set,uint32_t * vol, void *instance_data)
{
	int i, chn_idx;
	int32_t altered = 0;

	for(i = 0; i < aic3106->num_of_codecs; i++)
	{
		aic3106->left_adc_pga_gain_ctrl[i] = (aic3106_rd(aic3106, AIC3106_LEFT_ADC_PGA_GAIN_CTRL, aic3106->i2c_addr[i]));
		aic3106->right_adc_pga_gain_ctrl[i] = (aic3106_rd(aic3106, AIC3106_RIGHT_ADC_PGA_GAIN_CTRL, aic3106->i2c_addr[i]));
	}

	if(set)
	{
		for(i = 0, chn_idx = 0; i < aic3106->num_of_codecs; i++, chn_idx+=2)
		{
			/* If 4 channel configuration, skip over Front-Center channel placement */
			if (aic3106->hwc->cap_aif.cap_strm[0].voices == 4 && chn_idx == SND_MIXER_CHN_FRONT_CENTER)
				chn_idx++;

			if (vol[chn_idx] != (aic3106->left_adc_pga_gain_ctrl[i] & ADC_PGA_VOL_MASK))
			{
				altered = 1;
				aic3106->left_adc_pga_gain_ctrl[i] &= ADC_PGA_VOL_MUTE;
				aic3106->left_adc_pga_gain_ctrl[i] |= (vol[chn_idx] & ADC_PGA_VOL_MASK);
				aic3106_wr(aic3106, AIC3106_LEFT_ADC_PGA_GAIN_CTRL, aic3106->left_adc_pga_gain_ctrl[i], aic3106->i2c_addr[i]);
			}

			if (vol[chn_idx+1] != (aic3106->right_adc_pga_gain_ctrl[i] & ADC_PGA_VOL_MASK))
			{
				altered = 1;
				aic3106->right_adc_pga_gain_ctrl[i] &= ADC_PGA_VOL_MUTE;
				aic3106->right_adc_pga_gain_ctrl[i] |= (vol[chn_idx+1] & ADC_PGA_VOL_MASK);
				aic3106_wr(aic3106, AIC3106_RIGHT_ADC_PGA_GAIN_CTRL, aic3106->right_adc_pga_gain_ctrl[i], aic3106->i2c_addr[i]);
			}
		}
	}
	else
	{
		for(i = 0, chn_idx = 0; i < aic3106->num_of_codecs; i++, chn_idx+=2)
		{
			/* If 4 channel configuration, skip over Front-Center channel placement */
			if (aic3106->hwc->cap_aif.cap_strm[0].voices == 4 && chn_idx == SND_MIXER_CHN_FRONT_CENTER)
				chn_idx++;

			vol[chn_idx] = (aic3106->left_adc_pga_gain_ctrl[i] & ADC_PGA_VOL_MASK);
			vol[chn_idx+1] = (aic3106->right_adc_pga_gain_ctrl[i] & ADC_PGA_VOL_MASK);
		}
	}

	return (altered);
}

static int32_t
aic3106_input_mute_control(MIXER_CONTEXT_T * aic3106, ado_mixer_delement_t * element, uint8_t set,
						   uint32_t * val, void *instance_data)
{
	int i, chn_idx;
	uint32_t mute_map = 0;
	int32_t altered = 0;

	for (i = 0, chn_idx = 0; i < aic3106->num_of_codecs; i++, chn_idx+=2)
	{
		/* If 4 channel configuration, skip over Front-Center channel placement */
		if (aic3106->hwc->cap_aif.cap_strm[0].voices == 4 && chn_idx == SND_MIXER_CHN_FRONT_CENTER)
			chn_idx++;

		mute_map |= (aic3106->left_adc_pga_gain_ctrl[i] & ADC_PGA_VOL_MUTE) >> (7-chn_idx);
		mute_map |= (aic3106->right_adc_pga_gain_ctrl[i] & ADC_PGA_VOL_MUTE) >> (7-(chn_idx+1));
	}

	if (set)
	{
		altered = (mute_map != val[0]);
		if (altered)
		{
			for (i = 0, chn_idx = 0; i < aic3106->num_of_codecs; i++, chn_idx+=2)
			{
				/* If 4 channel configuration, skip over Front-Center channel placement */
				if (aic3106->hwc->cap_aif.cap_strm[0].voices == 4 && chn_idx == SND_MIXER_CHN_FRONT_CENTER)
					chn_idx++;

				aic3106->left_adc_pga_gain_ctrl[i] &= ADC_PGA_VOL_MASK;
				if (val[0] & (1<<chn_idx))
					aic3106->left_adc_pga_gain_ctrl[i] |= ADC_PGA_VOL_MUTE;

				aic3106->right_adc_pga_gain_ctrl[i] &= ADC_PGA_VOL_MASK;
				if (val[0] & (1<<(chn_idx+1)))
					aic3106->right_adc_pga_gain_ctrl[i] |= ADC_PGA_VOL_MUTE;

				aic3106_wr(aic3106, AIC3106_LEFT_ADC_PGA_GAIN_CTRL, aic3106->left_adc_pga_gain_ctrl[i], aic3106->i2c_addr[i]);
				aic3106_wr(aic3106, AIC3106_RIGHT_ADC_PGA_GAIN_CTRL, aic3106->right_adc_pga_gain_ctrl[i], aic3106->i2c_addr[i]);
			}
		}
	}
	else
	{
		val[0] = mute_map;
	}

	return (altered);
}

static int32_t build_aic3106_mixer(MIXER_CONTEXT_T * aic3106, ado_mixer_t * mixer)
{
	int error = 0;
	uint32_t chn_mask = 0;
	snd_mixer_voice_t *voices;

	ado_mixer_delement_t *play_vol;
	ado_mixer_delement_t *play_mute;
	ado_mixer_delement_t *play_out;
	ado_mixer_dgroup_t *play_grp;

	ado_mixer_delement_t *input_mux = NULL;

	ado_mixer_delement_t *input_vol = NULL;
	ado_mixer_delement_t *input_mute = NULL;

	ado_mixer_dgroup_t *linein_grp;
	ado_mixer_dgroup_t *micin_grp;
	ado_mixer_dgroup_t *igain_grp;

	ado_mixer_delement_t *pcm_out, *pcm_in = NULL;

	/**********************/
	/** the OUTPUT GROUP **/
	/**********************/

	if (aic3106->hwc->play_strm.voices)
	{
		switch (aic3106->hwc->play_strm.voices)
		{
			case 1:
				voices = mono_voices;
				chn_mask = SND_MIXER_CHN_MASK_MONO;
				break;
			case 2:
				voices = stereo_voices;
				chn_mask = SND_MIXER_CHN_MASK_STEREO;
				break;
			case 4:
			default:
				voices = quad_voices;
				chn_mask = SND_MIXER_CHN_MASK_4;
				break;
			case 6:
				voices = five_one_voices;
				chn_mask = SND_MIXER_CHN_MASK_5_1;
				break;
			case 8:
				voices = seven_one_voices;
				chn_mask = SND_MIXER_CHN_MASK_7_1;
				break;
		}

		if (!error && (pcm_out = ado_mixer_element_pcm1(mixer, SND_MIXER_ELEMENT_PLAYBACK,SND_MIXER_ETYPE_PLAYBACK1, 1,
															&pcm_devices[0])) == NULL)
			error++;

		if (!error && (play_vol = ado_mixer_element_volume1(mixer, "PCM Volume", aic3106->hwc->play_strm.voices, output_range,
															aic3106_output_vol_control, (void *) NULL, NULL)) == NULL)
			error++;

		if (!error && ado_mixer_element_route_add(mixer, pcm_out, play_vol) != 0)
			error++;

		if (!error && (play_mute = ado_mixer_element_sw1(mixer, "PCM Mute", aic3106->hwc->play_strm.voices, aic3106_output_mute_control,
															(void *) NULL, NULL)) == NULL)
			error++;

		if (!error && ado_mixer_element_route_add(mixer, play_vol, play_mute) != 0)
			error++;

		if (!error && (play_out = ado_mixer_element_io(mixer, "PCM_OUT", SND_MIXER_ETYPE_OUTPUT, 0,
														aic3106->hwc->play_strm.voices, voices)) == NULL)
			error++;
		if (!error && ado_mixer_element_route_add(mixer, play_mute, play_out) != 0)
			error++;

		if (!error && (play_grp = ado_mixer_playback_group_create(mixer, SND_MIXER_PCM_OUT, chn_mask, play_vol, play_mute)) == NULL)
			error++;

		/* If there is only 1 codec, create a headphone switch for output jack selection */
		if (aic3106->hwc->play_strm.voices == 1 || aic3106->hwc->play_strm.voices == 2)
		{
			if(!error &&
			   ado_mixer_switch_new(mixer, "Headphone Select", SND_SW_TYPE_BOOLEAN, 0, aic3106_hp_get, aic3106_hp_set, NULL, NULL) == NULL)
				error++;
		}
	}

	if (aic3106->hwc->cap_aif.cap_strm[0].voices)
	{
		/*********************/
		/** the INPUT GROUP **/
		/*********************/
		switch (aic3106->hwc->cap_aif.cap_strm[0].voices)
		{
			case 1:
				voices = mono_voices;
				chn_mask = SND_MIXER_CHN_MASK_MONO;
				break;
			case 2:
				voices = stereo_voices;
				chn_mask = SND_MIXER_CHN_MASK_STEREO;
				break;
			case 4:
			default:
				voices = quad_voices;
				chn_mask = SND_MIXER_CHN_MASK_4;
				break;
			case 6:
				voices = five_one_voices;
				chn_mask = SND_MIXER_CHN_MASK_5_1;
				break;
			case 8:
				voices = seven_one_voices;
				chn_mask = SND_MIXER_CHN_MASK_7_1;
				break;
		}

		if(!error && (input_vol = ado_mixer_element_volume1(mixer, "Input Volume", aic3106->hwc->cap_aif.cap_strm[0].voices, input_range,
															aic3106_input_vol_control, (void*) NULL, NULL)) == NULL)
			error++;

		if(!error && (input_mute = ado_mixer_element_sw1(mixer, "Input Mute", aic3106->hwc->cap_aif.cap_strm[0].voices,
															aic3106_input_mute_control, NULL, NULL)) == NULL)
			error++;

		if(!error && ado_mixer_element_route_add(mixer, input_vol, input_mute) != 0)
			error++;

		if(!error && (pcm_in = ado_mixer_element_pcm1(mixer, SND_MIXER_ELEMENT_CAPTURE, SND_MIXER_ETYPE_CAPTURE1, 1,
														&pcm_devices[0])) == NULL)
			error++;

		if(!error && ado_mixer_element_route_add(mixer, input_mute, pcm_in) != 0)
			error++;

		if(!error && (igain_grp = ado_mixer_capture_group_create(mixer, SND_MIXER_GRP_IGAIN, chn_mask, input_vol,
																	input_mute, NULL, NULL)) == NULL)
			error++;

		/* There is only 1 codec so create mux element and mic and line groups for input jack selection */
		if (aic3106->hwc->cap_aif.cap_strm[0].voices == 1 || aic3106->hwc->cap_aif.cap_strm[0].voices == 2)
		{
			if(!error && (input_mux = ado_mixer_element_mux1(mixer, "Input Mux", 0, aic3106->hwc->cap_aif.cap_strm[0].voices,
																aic3106_mux_control, NULL, NULL)) == NULL)
				error++;

			if(!error && ado_mixer_element_route_add(mixer, input_mux, input_vol) != 0)
				error++;

			if(!error && (aic3106->aux_in = ado_mixer_element_io(mixer, "LINEIN", SND_MIXER_ETYPE_INPUT, 0,
																	aic3106->hwc->cap_aif.cap_strm[0].voices, voices)) == NULL)
				error++;

			if(!error && ado_mixer_element_route_add(mixer, aic3106->aux_in, input_mux) != 0)
				error++;

			if(!error && (linein_grp = ado_mixer_capture_group_create(mixer, SND_MIXER_LINE_IN, chn_mask, NULL, NULL, input_mux,
																		aic3106->aux_in)) == NULL)
				error++;

			if(!error && (aic3106->mic1_in = ado_mixer_element_io(mixer, "MICIN", SND_MIXER_ETYPE_INPUT, 0,
																	aic3106->hwc->cap_aif.cap_strm[0].voices, voices)) == NULL)
				error++;

			if(!error && ado_mixer_element_route_add(mixer, aic3106->mic1_in, input_mux) != 0)
				error++;

			if(!error && (micin_grp = ado_mixer_capture_group_create(mixer, SND_MIXER_MIC_IN, chn_mask,	NULL, NULL, input_mux,
																		aic3106->mic1_in)) == NULL)
				error++;
		}
		else
		{
			/* Multiple codecs groups together with all audio jacks active, create an io element that sits directly
			 * infront of the input_vol element since there is no input mux in this case.
			 */
			if(!error && (aic3106->aux_in = ado_mixer_element_io(mixer, "PCM IN", SND_MIXER_ETYPE_INPUT, 0,
																	aic3106->hwc->cap_aif.cap_strm[0].voices, voices)) == NULL)
				error++;

			if(!error && ado_mixer_element_route_add(mixer, aic3106->aux_in, input_vol) != 0)
				error++;
		}
	}

	return (!error ? 0 : -1);
}

static ado_mixer_reset_t aic3106_reset;
static int aic3106_reset(MIXER_CONTEXT_T * aic3106)
{
	int j;
	uint8_t regVal;
	int ind;

	int8_t wr_ret = 0;

	for(j=0; j < aic3106->num_of_codecs; j++)
	{
		/* Select Page 0 and reset codec */
		wr_ret |= aic3106_wr(aic3106, AIC3106_PAGESELECTOR, PAGE_SELECT, aic3106->i2c_addr[j]);
		wr_ret |= aic3106_wr(aic3106, AIC3106_SFT_RESET, SFT_RESET, aic3106->i2c_addr[j]);

		if( MASTER == aic3106->hwc->clk_mode)
		{
			/* BCLK and WCLK as input, slave mode, Place DOUT in high impedance when valid data is not being sent */
			wr_ret |= aic3106_wr(aic3106, AIC3106_AUDIO_SER_DATA_INT_CTRL_A, REG_A_SERIAL_DOUT_3STATE_CTRL, aic3106->i2c_addr[j]);
		}
		else
		{ /* McASP is SLAVE -> Codec is Master */

			/* BCLK and WCLK as output, master mode, Place DOUT in high impedance when valid data is not being sent */
			wr_ret |= aic3106_wr(aic3106, AIC3106_AUDIO_SER_DATA_INT_CTRL_A,(REG_A_BCLK_DIR_CTRL | REG_A_WCLK_DIR_CTRL | REG_A_SERIAL_DOUT_3STATE_CTRL), aic3106->i2c_addr[j]);

			for(ind=0; ind < NUM_CLOCK_ENTRIES; ind++)
			{
				if(aic3106->hwc->mclk == codec_pll_dividers[ind][0])
				{
					/* found the correct mclk */

					if(0 == codec_pll_dividers[ind][PLL_Q_INDEX])
					{
						/* Q=0 means we need to enable PLL and use the values for P,R,J and D */
						wr_ret |= aic3106_wr(aic3106, AIC3106_PLL_PROGRAM_REG_A,(REG_A_PLL_CTRL | REG_A_PLL_P(codec_pll_dividers[ind][PLL_P_INDEX])), aic3106->i2c_addr[j]);
						wr_ret |= aic3106_wr(aic3106, AIC3106_PLL_PROGRAM_REG_B, REG_B_PLL_J(codec_pll_dividers[ind][PLL_J_INDEX]), aic3106->i2c_addr[j]);
						wr_ret |= aic3106_wr(aic3106, AIC3106_PLL_PROGRAM_REG_C, REG_C_PLL_D_MOST_BIT(codec_pll_dividers[ind][PLL_D_INDEX]), aic3106->i2c_addr[j]);
						wr_ret |= aic3106_wr(aic3106, AIC3106_PLL_PROGRAM_REG_D, REG_D_PLL_D_LEAST_BIT(codec_pll_dividers[ind][PLL_D_INDEX]), aic3106->i2c_addr[j]);
						wr_ret |= aic3106_wr(aic3106, AIC3106_AUDIO_CODEC_OVERFLOW_FLAG, OVERFLOW_FLAG_PLL_R(codec_pll_dividers[ind][PLL_R_INDEX]), aic3106->i2c_addr[j]);

					}
					else
					{
						/* A non-zero value for Q means the do not need to use the PLL */
						wr_ret |= aic3106_wr(aic3106, AIC3106_PLL_PROGRAM_REG_A,REG_A_PLL_Q(codec_pll_dividers[ind][PLL_Q_INDEX]), aic3106->i2c_addr[j]);
					}
					break;

				}
			}
			if(ind == NUM_CLOCK_ENTRIES)
			{
				ado_error("aic3106: invalid MCLK value (%d)", aic3106->hwc->mclk);
				return(-1);
			}
		}


		/* use DSP mode for num_of_codecs > 1 and I2S mode for num_of_codecs == 1
		 * 16-bit word (default)
		 */
		if(aic3106->num_of_codecs > 1)
		{
			/* DSP Mode
			 * Note: In DSP mode the first channel starts at the programmed data offset and
			 *       the second channel immediately follows the first channel (no gaps),
			 *       so the TDM slot size must == the sample size.
			 */
			wr_ret |= aic3106_wr(aic3106, AIC3106_AUDIO_SER_DATA_INT_CTRL_B, REG_B_AUDIO_SERIAL_DSP_MODE, aic3106->i2c_addr[j]);
			/* Set data offset (i.e TDM slot selection) */
			wr_ret |= aic3106_wr(aic3106, AIC3106_AUDIO_SER_DATA_INT_CTRL_C, (((j)<<5)), aic3106->i2c_addr[j]);
		}
		else
		{
			/* I2S Mode */
			wr_ret |= aic3106_wr(aic3106, AIC3106_AUDIO_SER_DATA_INT_CTRL_B, REG_B_AUDIO_SERIAL_I2S_MODE, aic3106->i2c_addr[j]);
		}

		/************/
		/** INPUTS **/
		/************/

		/* Ensure Digital Filter Control is OFF */
		wr_ret |= aic3106_wr(aic3106, AIC3106_AUDIO_CODEC_DFC, 0x0, aic3106->i2c_addr[j]);

		if(SEL_MCASP2 == aic3106->sel_mcasp)
		{
			/* connect MIC3L to Left ADC and MIC3R to right ADC */
			wr_ret |= aic3106_wr(aic3106, AIC3106_MIC3LR_TO_LEFT_ADC_CTRL, MIC3R_INPUT_LEVEL_CTRL_LEFT_ADC_PGA_MIX, aic3106->i2c_addr[j]);
			wr_ret |= aic3106_wr(aic3106, AIC3106_MIC3LR_TO_RIGHT_ADC_CTRL, MIC3L_INPUT_LEVEL_CTRL_RIGHT_ADC_PGA_MIX, aic3106->i2c_addr[j]);

			/* disconnect Line1L and Line1R from Left and Right ADC (can connect through mux) */
			wr_ret |= aic3106_wr(aic3106, AIC3106_LINE1L_TO_LEFT_ADC_CTRL, LINE1L_INPUT_LEVEL_CTRL_LEFT_ADC_PGA_MIX, aic3106->i2c_addr[j]);
			wr_ret |= aic3106_wr(aic3106, AIC3106_LINE1R_TO_RIGHT_ADC_CTRL, LINE1R__INPUT_LEVEL_CTRL_RIGHT_ADC_PGA_MIX, aic3106->i2c_addr[j]);
		}
		else if(SEL_MCASP5 == aic3106->sel_mcasp)
		{
			/* LINE1L to Left ADC: fully differential & volume (0db) */
			wr_ret |= aic3106_wr(aic3106, AIC3106_LINE1L_TO_LEFT_ADC_CTRL, (1<<7) | (0<<2),  aic3106->i2c_addr[j]);

			/* LINE1R to Right ADC: fully differential & volume (0db), power-on */
			wr_ret |= aic3106_wr(aic3106, AIC3106_LINE1R_TO_RIGHT_ADC_CTRL, (1<<7) | (0<<2),  aic3106->i2c_addr[j]);
		}

		/* turn on microphone biasing */
		wr_ret |= aic3106_wr(aic3106, AIC3106_MICBIAS_CTRL, MICBIAS_AVDD, aic3106->i2c_addr[j]);

		/* set Left and Right ADC to (29.5 db (50%)) */
		aic3106->left_adc_pga_gain_ctrl[j] = 0x3b;
		aic3106->right_adc_pga_gain_ctrl[j] = 0x3b;
		wr_ret |= aic3106_wr(aic3106, AIC3106_LEFT_ADC_PGA_GAIN_CTRL, aic3106->left_adc_pga_gain_ctrl[j], aic3106->i2c_addr[j]);
		wr_ret |= aic3106_wr(aic3106, AIC3106_RIGHT_ADC_PGA_GAIN_CTRL, aic3106->right_adc_pga_gain_ctrl[j], aic3106->i2c_addr[j]);

		/* Turn on Left and Right ADC */
		regVal = aic3106_rd(aic3106, AIC3106_LINE1L_TO_LEFT_ADC_CTRL, aic3106->i2c_addr[j]);
		wr_ret |= aic3106_wr(aic3106, AIC3106_LINE1L_TO_LEFT_ADC_CTRL, regVal | (1<<2), aic3106->i2c_addr[j]);
		regVal = aic3106_rd(aic3106, AIC3106_LINE1R_TO_RIGHT_ADC_CTRL, aic3106->i2c_addr[j]);
		wr_ret |= aic3106_wr(aic3106, AIC3106_LINE1R_TO_RIGHT_ADC_CTRL, regVal | (1<<2), aic3106->i2c_addr[j]);

		/*************/
		/** OUTPUTS **/
		/*************/

		/* Enable POP reduction */
		wr_ret |= aic3106_wr(aic3106, AIC3106_OUTPUT_DRIVER_POP_REDUCTION, POWER_ON_TIME_4S | RAMP_UP_STEP_TIME_2MS, aic3106->i2c_addr[j]);

		/* Power up Left and Right DAC */
		wr_ret |= aic3106_wr(aic3106, AIC3106_DAC_POWER_DRIVER_CTRL, (LEFT_DAC_POWER_CTRL | RIGHT_DAC_POWER_CTRL), aic3106->i2c_addr[j]);

		/* set output vol to 100% (0db) */
		aic3106->left_dac_vol_ctrl[j] = 0x0;
		aic3106->right_dac_vol_ctrl[j] = 0x0;
		wr_ret |= aic3106_wr(aic3106, AIC3106_LEFT_DAC_DIG_VOL_CTRL, aic3106->left_dac_vol_ctrl[j], aic3106->i2c_addr[j]);
		wr_ret |= aic3106_wr(aic3106, AIC3106_RIGHT_DAC_DIG_VOL_CTRL, aic3106->right_dac_vol_ctrl[j], aic3106->i2c_addr[j]);

		/* Select DAC route 1 (to analog mixer) */
		wr_ret |= aic3106_wr(aic3106, AIC3106_DAC_OUTPUT_SWITCH_CTRL, 0x0, aic3106->i2c_addr[j]);

		if(SEL_MCASP2 == aic3106->sel_mcasp)
		{
			/* HPL/ROUT Vol Ctrl (0db) + not muted + powered on */
			wr_ret |= aic3106_wr(aic3106, AIC3106_HPLOUT_OUTPUT_LVL_CTRL, (HPLOUT_POWER_CTRL | HPLOUT_MUTE), aic3106->i2c_addr[j]);
			wr_ret |= aic3106_wr(aic3106, AIC3106_HPROUT_OUTPUT_LVL_CTRL, (HPROUT_POWER_CTRL | HPROUT_MUTE), aic3106->i2c_addr[j]);
		}

		/* Ensure DAC_L1/DAC_R1 is disconnected from LOP (Line output) during power on */
		wr_ret |= aic3106_wr(aic3106, AIC3106_DAC_L1_TO_LEFTLOP_VOL_CTRL, 0x0, aic3106->i2c_addr[j]);
		wr_ret |= aic3106_wr(aic3106, AIC3106_DAC_R1_TO_RIGHTLOP_VOL_CTRL, 0x0, aic3106->i2c_addr[j]);

		/* Line out - 0db, unmute + power on
		 * NOTE: We get a pop/click when LOP power is enabled for the first time after boot
		 */
		wr_ret |= aic3106_wr(aic3106, AIC3106_LEFTLOP_OUTPUT_LVL_CTRL, (LEFTLOP_LEFT_LOP_M_POWER_STATUS | LEFTLOP_LEFT_LOP_M_MUTE), aic3106->i2c_addr[j]);
		wr_ret |= aic3106_wr(aic3106, AIC3106_RIGHTLOP_OUTPUT_LVL_CTRL, (RIGHTLOP_RIGHT_LOP_M_POWER_STATUS | RIGHTLOP_RIGHT_LOP_M_MUTE), aic3106->i2c_addr[j]);

		/* Route DAC to Lineout via analog mixer */
		wr_ret |= aic3106_wr(aic3106, AIC3106_DAC_L1_TO_LEFTLOP_VOL_CTRL, DAC_L1_ROUTED_TO_LEFTLOP, aic3106->i2c_addr[j]);
		wr_ret |= aic3106_wr(aic3106, AIC3106_DAC_R1_TO_RIGHTLOP_VOL_CTRL, DAC_R1_ROUTED_TO_RIGHTLOP, aic3106->i2c_addr[j]);
	}
	if (wr_ret)
	{
		ado_error("aic3106: write register failed, codec reset cannot complete!\n");
		return -1;
	}
	return (0);
}

void
codec_set_default_group( ado_pcm_t *pcm, ado_mixer_t *mixer, int channel, int index )
{

    switch (channel)
    {
        case ADO_PCM_CHANNEL_PLAYBACK:
            ado_pcm_chn_mixer (pcm, ADO_PCM_CHANNEL_PLAYBACK, mixer,
                ado_mixer_find_element (mixer, SND_MIXER_ETYPE_PLAYBACK1,
                    SND_MIXER_ELEMENT_PLAYBACK, index), ado_mixer_find_group (mixer,
                    SND_MIXER_PCM_OUT, index));
            break;
        case ADO_PCM_CHANNEL_CAPTURE:
            ado_pcm_chn_mixer (pcm, ADO_PCM_CHANNEL_CAPTURE, mixer,
                ado_mixer_find_element (mixer, SND_MIXER_ETYPE_CAPTURE1,
                    SND_MIXER_ELEMENT_CAPTURE, index), ado_mixer_find_group (mixer,
                    SND_MIXER_GRP_IGAIN, index));
            break;
        default:
            break;
    }
}

static ado_mixer_destroy_t aic3106_destroy;
static int aic3106_destroy(MIXER_CONTEXT_T * aic3106)
{
	int i;
	ado_debug(DB_LVL_MIXER, "destroying AIC3106 Codec");

	for(i = 0; i < aic3106->num_of_codecs; i++)
	{
		aic3106_wr(aic3106, AIC3106_SFT_RESET, SFT_RESET, aic3106->i2c_addr[i]);
	}
	close(aic3106->fd);
	ado_free(aic3106);

	return (0);
}

/**
 * This function is responsible for configuring the aic3106 chip's
 * sample rates
 */
int
aic3106_set_sample_rate(MIXER_CONTEXT_T *aic3106)
{
	uint8_t value;
	int      i;

	for(i = 0; i < aic3106->num_of_codecs; i++)
	{
		aic3106_wr(aic3106, AIC3106_CODEC_SAMPLE_RATE_SELEC, 0x0, aic3106->i2c_addr[i]);
		// Left and Right DAC datapath control + sampling frequency
		value = (RIGTH_DAC_DATAPATH_CTRL | LEFT_DAC_DATAPATH_CTRL);
		if (aic3106->hwc->play_strm.sample_rate == 44100)
			value |= AGC_FS_REF_44100;
		aic3106_wr(aic3106, AIC3106_CODEC_DATAPATH_SETUP, value, aic3106->i2c_addr[i]);
	}
	return 0;
}

int
codec_mixer(ado_card_t * card, HW_CONTEXT_T * hwc)
{
	int32_t status;
	char i2c_port[20];
	unsigned int speed;
	aic3106_context_t *aic3106;

	ado_debug(DB_LVL_MIXER, "initializing AIC3106A Codec");

	if ((aic3106 = (aic3106_context_t *) ado_calloc(1, sizeof (aic3106_context_t))) == NULL)
	{
		ado_error("aic3106: no memory %s", strerror(errno));
		return (-1);
	}
	if ((status = ado_mixer_create(card, "aic3106", &hwc->mixer, aic3106)) != EOK)
	{
		ado_free(aic3106);
		return (status);
	}
	aic3106->mixer = hwc->mixer;
	aic3106->hwc = hwc;
	aic3106->output_routing = SWITCH_LINEOUT; /* valid for McASP2, ignored otherwise */
	aic3106->input_mux = MIC1_IN_INPUT;

	/* determine which mcasp is being used */
	if(hwc->mcasp_baseaddr == MCASP2_BASEADDR)
		aic3106->sel_mcasp = SEL_MCASP2;
	else if(hwc->mcasp_baseaddr == MCASP5_BASEADDR)
		aic3106->sel_mcasp = SEL_MCASP5;

	if(hwc->i2c_dev == 0xff)
	{
		ado_debug(DB_LVL_DRIVER, "No i2c device selected (will assume Mcasp2 --> i2c0, Mcasp5 -->i2c2)");
		if(SEL_MCASP2 == aic3106->sel_mcasp)
			hwc->i2c_dev = 0;
		else if(SEL_MCASP5 == aic3106->sel_mcasp)
			hwc->i2c_dev = 2;
	}

	sprintf(i2c_port, "/dev/i2c%d", hwc->i2c_dev);
	if ((aic3106->fd = open(i2c_port, O_RDWR)) < 0)
	{
		ado_error("aic3106: could not open i2c device %s", strerror(errno));
		ado_free(aic3106);
		return (-1);
	}

	/* Set the bus speed to 400K */
    speed = 400000;
    if (devctl (aic3106->fd, DCMD_I2C_SET_BUS_SPEED, &speed, sizeof (speed), NULL))
    {
        ado_error ("aic3106: Failed to set I2C bus speed\n");
        close (aic3106->fd);
        ado_free (aic3106);
        return -1;
    }

	aic3106->num_of_codecs = hwc->play_strm.voices>>1; // each codes supports two channels

	aic3106->i2c_addr[0] = hwc->codec_i2c_addr;
	aic3106->i2c_addr[1] = hwc->codec_i2c_addr + 1; // will be ignored for McASP2
	aic3106->i2c_addr[2] = hwc->codec_i2c_addr + 2; // will be ingnored for McASP2

	/* reset codec(s) */
	if(aic3106_reset(aic3106) == -1)
	{
		ado_error("aic3106: could not initialize codec");
		close(aic3106->fd);
		ado_free(aic3106);
		return (-1);
	}

	/* set sample rate */
	aic3106_set_sample_rate(aic3106);

	if (build_aic3106_mixer(aic3106, aic3106->mixer))
	{
		close(aic3106->fd);
		ado_free(aic3106);
		return (-1);
	}

	ado_mixer_set_reset_func(aic3106->mixer, aic3106_reset);
	ado_mixer_set_destroy_func(aic3106->mixer, aic3106_destroy);

	return (0);
}

#if defined(__QNXNTO__) && defined(__USESRCVERSION)
#include <sys/srcversion.h>
__SRCVERSION("$URL: http://svn.ott.qnx.com/product/branches/6.6.0/trunk/hardware/deva/ctrl/mcasp/nto/arm/dll.le.aic3106.v7/aic3106.c $ $Rev: 812897 $")
#endif
