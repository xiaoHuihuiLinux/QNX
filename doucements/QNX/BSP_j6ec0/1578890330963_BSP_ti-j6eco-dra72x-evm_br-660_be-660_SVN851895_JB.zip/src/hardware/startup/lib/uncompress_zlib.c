/*
 * $QNXLicenseC:
 * Copyright 2017, QNX Software Systems.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"). You 
 * may not reproduce, modify or distribute this software except in 
 * compliance with the License. You may obtain a copy of the License 
 * at: http://www.apache.org/licenses/LICENSE-2.0 
 * 
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" basis, 
 * WITHOUT WARRANTIES OF ANY KIND, either express or implied.
 *
 * This file may contain contributions from others, either as 
 * contributors under the License or as licensors under other terms.  
 * Please review this entire file for other proprietary rights or license 
 * notices, as well as the QNX Development Suite License Guide at 
 * http://licensing.qnx.com/license-guide/ for other information.
 * $
 */

#include "startup.h"
/* Without the two defines below, we run into ugly compiler errors.      */
/* "startup.h" defines its own getopt(), which has a different signature */
/* than the one defined in "unistd.h" (which is pulled in via "zlib.h"). */
/* Also, zlib has its own uncompress() function, which is something      */
/* entirely else than the one in "uncompress.c". Luckily, we don't use   */
/* zlib's uncompress() function, so define thatout of the way as well.   */
#define getopt zzz_getopt
#define uncompress zzz_uncompress
#include <zconf.h>
#include <zlib.h>


/* These two functions are actually defined in libz, and should in theory    */
/* be overriden using strm->zalloc and strm->zfree. But even then would the  */
/* linker pull in those functions, together with their containing object.    */
/* That ends up producing a clash between libc's pci_attach_device() and     */
/* the one that our startup library brings. To avoid this clash, I chose     */
/* to implement these two functions (which don't get called anyway) in here. */
void
*zcalloc(void *opaque, uInt items, uInt size) {
	void  *p = ws_alloc(items * size);
	kprintf("zcalloc(0x%x, %u, %u) -> 0x%x\n",
	        (unsigned) opaque, items, size, (unsigned) p);
	return p;
}

void
zcfree(void *opaque, void *address) {
	kprintf("zcfree(0x%x, 0x%x)\n", (unsigned) opaque, (unsigned) address);
}

void
uncompress_zlib(uint8_t *dst, unsigned dstlen, uint8_t *src, unsigned srclen) {
	z_stream  strm;
	int  e;

	strm.zalloc    = Z_NULL;
	strm.zfree     = Z_NULL;
	strm.opaque    = Z_NULL;
	strm.next_in   = src;
	strm.avail_in  = srclen;
	strm.next_out  = dst;
	strm.avail_out = dstlen;

	/* Use magic window size 31 to turn on automatic gzip detection and handling. */
	/* Officially, the maximum window size is 15, and zlib will internally set    */
	/* the effective window size to the provided size modulo 15 - but the bit #4  */
	/* ends up indicating that the GZ gear should be turned on.                   */
	inflateInit2(&strm, 31);

	/* The 'flush' value of Z_FINISH instructs libz to perform the entire */
	/* decompression in one inflate() call. This can be done here because */
	/* we have all necessary source data in memory, and sufficient RAM at */
	/* our disposal to uncompress into.                                   */
	e = inflate(&strm, Z_FINISH);
	if(Z_STREAM_END != e) {
		crash("inflate() -- %s", strm.msg ? strm.msg : "compressed data error");
	}

	inflateEnd(&strm);
}

#if defined(__QNXNTO__) && defined(__USESRCVERSION)
#include <sys/srcversion.h>
__SRCVERSION("$URL: http://svn.ott.qnx.com/product/branches/6.6.0/trunk/hardware/startup/lib/uncompress_zlib.c $ $Rev: 842805 $")
#endif
